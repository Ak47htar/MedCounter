# MedTally Pro 1.1 - bug-fix release

Version 1.0 (code 1) -> **1.1 (code 2)**. `applicationId` is unchanged.

## Getting an APK

This project could not be compiled where the fixes were made (no Android SDK / Gradle / Maven access),
so the APK has to be built on your side. Pick one:

1. **GitHub Actions (no installs).** Push this folder (the one containing `settings.gradle.kts`) to a
   GitHub repository. The workflow in `.github/workflows/build-apk.yml` starts by itself (or use *Actions* ->
   **Build Android APK** -> *Run workflow*). When it finishes, the APK is on the repository's **Releases** page
   (`MedTally-Pro-debug.apk`, tap it to download) and in the run's *Artifacts* (`medtally-pro-apk`). If the build
   fails, the run's *Summary* shows the real error and the artifact `build-log` has the full output.
2. **Android Studio.** Open this folder, let Gradle sync, then *Build > Build APK(s)*. The file ends up in
   `app/build/outputs/apk/debug/app-debug.apk`.
3. **Command line.** With JDK 17+ and the Android SDK installed: `gradle :app:assembleDebug`
   (Gradle 9.3.1, as in `gradle/wrapper/gradle-wrapper.properties`).

**Updating an installed copy:** Android only installs an update over an existing app if both APKs are
signed with the same key. An APK you build yourself is signed with *your* debug key, so if the old app
came from somewhere else you may have to uninstall it first, **which deletes its local data**. Use
*Audit Log > Copy Report* beforehand if you need the history.

## What was fixed

### Build
- `assembleDebug` failed in a normal checkout: the debug build type required `debug.keystore`, which is
  git-ignored and not part of the project. It is now used only when the file exists.
- `assembleRelease` failed without the AI Studio upload key. It now falls back to the debug key (installable,
  but not suitable for Play Store upload).

### Data integrity
- **Demo medicines were created twice on first launch** (a database callback and the ViewModel both seeded) and
  **came back after you deleted them all** (the ViewModel re-seeded whenever the table was empty). Seeding now
  happens once, inside database creation.
- **Counting is atomic.** The new value used to be computed from the value currently on screen, so a tap that
  arrived before the screen had caught up (slow/busy phone, very fast tapping) overwrote the previous one, and
  the audit log could disagree with the stored count. The change and its audit entry are now one transaction,
  computed from the stored row. Counts are clamped to 0..Int.MAX (a huge step used to overflow).
- Editing a medicine no longer writes back an old count.
- **Audit export** was silently limited to the 200 rows shown on screen. It now reads the database (latest 1,500
  entries, with the header stating "showing the latest N of M" if capped) and no longer crashes if the clipboard
  rejects a huge report.
- Applying a photo scan clears the photo, so the same scan can't be counted twice.

### Camera
- **Freeze Photo** decoded the captured JPEG as if it were raw NV21 pixels, which can only give a garbage
  image. It now decodes the JPEG properly (downsampled, rotated) off the UI thread, and reports failures.
- **The camera is released when you leave the screen.** It previously stayed open (and the torch on) behind the
  other tabs. The torch state is re-applied correctly, and the last count/boxes are cleared on exit (a stale
  "ADD +N" could be tapped on re-entry).
- **Boxes now line up with the preview.** The preview is centre-cropped but boxes were drawn as if the whole
  frame were visible; items outside the visible area were also counted. Boxes are mapped to what is on screen
  and only visible items are counted. The count is a median of the last 5 frames, so a one-frame spike can't be
  added to stock.
- Permission: re-checked when you return from system settings, plus an "Open App Settings" button for the
  "don't ask again" case.
- The detector's inner loop no longer allocates objects per pixel (output verified identical to the old one on
  8,000 synthetic comparisons), and no longer throws on bitmaps smaller than 32 px.

### Photo scan
- Boxes and taps were mapped to the whole screen area instead of the letter-boxed photo, so they were misplaced
  whenever the photo's shape differed from the screen (always, for landscape photos). Taps in the bars are ignored.
- Gallery photos: decoded down-sampled (full-size 50-200 MP photos ran out of memory), EXIF rotation applied
  (phone photos appeared sideways), decoded off the UI thread, with an error message on failure.
- The sensitivity slider is debounced and cancels stale analyses; manual markers survive re-analysis; a new photo
  never inherits the previous photo's markers. Apply is disabled when no medicine exists.

### UI
- Counter screen: the "Remove" button shared a row with five other controls; by my width calculation it was left
  too little room on typical phone widths, so its label would wrap. Remove/Reset and the +1/+5/+10 pills are now
  separate rows.
- Medicine tabs/cards are sorted by name, not "last changed", so they no longer jump to the front while you count.
- Number keyboards and sane length limits for target/step fields; the target dialog no longer shows stale text;
  the expiry label says MM/YYYY (matching its placeholder and data).
- Photo screen no longer applies the status/navigation-bar insets twice; the camera settings card now starts
  below the status bar instead of at a fixed offset; the adaptive icon no longer has a broken "themed icon" layer (it pointed at an opaque JPG).

## Tests
`app/src/test` gained 26 JVM unit tests (viewport geometry, count smoothing, bitmap sampling, audit report
format). They contain no Android dependencies.

## Deliberately not changed
- The demo medicines **and their fake audit entries** are still created on first run. For real stock-keeping
  you probably want to remove `seedInitialData` in `AppDatabase.kt`.
- Firebase AI / App Check dependencies are in the build but unused by the app code.
- `itemsPerUnit` is stored but never used.
