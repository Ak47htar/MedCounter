package com.example

import com.example.data.AuditReportFormatter
import com.example.data.TallyLogEntity
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class AuditReportFormatterTest {

    private val now = Date(1_700_000_000_000L) // 2023-11-14 22:13:20 UTC
    private fun report(logs: List<TallyLogEntity>, total: Int = logs.size) =
        AuditReportFormatter.format(logs, total, now, Locale.US, TimeZone.getTimeZone("UTC"))

    private fun log(
        id: Long, change: Int, result: Int, target: Int = 0, batch: String = "B1",
        method: String = "MANUAL_TAP", ts: Long = 1_700_000_000_000L
    ) = TallyLogEntity(
        id = id, medicineId = 1, medicineName = "Amoxicillin", batchNumber = batch,
        countChange = change, resultingCount = result, targetCount = target,
        method = method, note = "n$id", timestamp = ts
    )

    @Test
    fun emptyLog_saysSo() {
        val text = report(emptyList())
        assertTrue(text.contains("Entries: 0"))
        assertTrue(text.contains("No logs recorded."))
        assertTrue(text.contains("Generated: 2023-11-14 22:13:20"))
    }

    @Test
    fun entries_areFormattedWithSignedChange() {
        val text = report(listOf(log(1, +5, 13, target = 25), log(2, -1, 12, target = 25)))
        assertTrue(text.contains("Change: +5 -> Result: 13/25"))
        assertTrue(text.contains("Change: -1 -> Result: 12/25"))
        assertTrue(text.contains("2023-11-14 22:13:20 | Amoxicillin"))
        assertTrue(text.contains("Method: MANUAL_TAP | Note: n1"))
    }

    @Test
    fun noTarget_doesNotPrintSlashZero_andEmptyBatchIsNA() {
        val text = report(listOf(log(1, +3, 3, target = 0, batch = "")))
        assertTrue(text.contains("Result: 3\n"))
        assertFalse(text.contains("3/0"))
        assertTrue(text.contains("Batch: N/A"))
    }

    @Test
    fun truncatedExport_isLabelledSoItCannotBeMistakenForComplete() {
        val text = report(listOf(log(1, 1, 1), log(2, 1, 2)), total = 5)
        assertTrue(text.contains("Entries: showing the latest 2 of 5"))
    }

    @Test
    fun completeExport_saysEntryCount() {
        assertTrue(report(listOf(log(1, 1, 1), log(2, 1, 2))).contains("Entries: 2"))
    }
}
