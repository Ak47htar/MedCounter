package com.example

import com.example.vision.DetectedBox
import com.example.vision.ViewportMapper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ViewportMapperTest {

    private val eps = 0.0001f

    private fun box(l: Float, t: Float, r: Float, b: Float, units: Int = 1) =
        DetectedBox(id = 1, left = l, top = t, right = r, bottom = b, estimatedUnits = units)

    // ---- fillCenterRegion (camera preview is centre-cropped) ----

    @Test
    fun tallView_cropsLeftAndRightOfFrame() {
        // 3:4 portrait frame shown on a very tall phone screen (aspect 0.5)
        val r = ViewportMapper.fillCenterRegion(frameAspect = 0.75f, viewAspect = 0.5f)
        assertEquals(1f / 6f, r.left, eps)
        assertEquals(5f / 6f, r.right, eps)
        assertEquals(0f, r.top, eps)
        assertEquals(1f, r.bottom, eps)
    }

    @Test
    fun wideView_cropsTopAndBottomOfFrame() {
        val r = ViewportMapper.fillCenterRegion(frameAspect = 0.75f, viewAspect = 1.5f)
        assertEquals(0f, r.left, eps)
        assertEquals(1f, r.right, eps)
        assertEquals(0.25f, r.top, eps)
        assertEquals(0.75f, r.bottom, eps)
    }

    @Test
    fun sameAspect_orUnknown_showsWholeFrame() {
        assertEquals(ViewportMapper.Region.FULL, ViewportMapper.fillCenterRegion(0.75f, 0.75f))
        assertEquals(ViewportMapper.Region.FULL, ViewportMapper.fillCenterRegion(0f, 0.5f))
        assertEquals(ViewportMapper.Region.FULL, ViewportMapper.fillCenterRegion(0.75f, 0f))
        assertEquals(ViewportMapper.Region.FULL, ViewportMapper.fillCenterRegion(Float.NaN, 0.5f))
        assertEquals(ViewportMapper.Region.FULL, ViewportMapper.fillCenterRegion(0.75f, Float.POSITIVE_INFINITY))
    }

    // ---- toViewBox ----

    @Test
    fun boxInsideRegion_isRemappedToViewCoordinates() {
        val region = ViewportMapper.Region(0.25f, 0f, 0.75f, 1f)
        val mapped = ViewportMapper.toViewBox(box(0.3f, 0.2f, 0.5f, 0.6f), region)
        assertNotNull(mapped)
        assertEquals(0.1f, mapped!!.left, eps)
        assertEquals(0.5f, mapped.right, eps)
        assertEquals(0.2f, mapped.top, eps)
        assertEquals(0.6f, mapped.bottom, eps)
    }

    @Test
    fun boxCentreOutsideRegion_isDropped() {
        val region = ViewportMapper.Region(0.25f, 0f, 0.75f, 1f)
        assertNull(ViewportMapper.toViewBox(box(0.0f, 0.2f, 0.2f, 0.6f), region))
        assertNull(ViewportMapper.toViewBox(box(0.8f, 0.2f, 0.95f, 0.6f), region))
    }

    @Test
    fun boxStickingOutOfView_isClippedButKept() {
        val region = ViewportMapper.Region(0.25f, 0f, 0.75f, 1f)
        val mapped = ViewportMapper.toViewBox(box(0.2f, 0.2f, 0.4f, 0.6f), region) // centre 0.3 is visible
        assertNotNull(mapped)
        assertEquals(0f, mapped!!.left, eps)          // clipped at the view edge
        assertEquals(0.3f, mapped.right, eps)
    }

    @Test
    fun visibleCount_ignoresItemsThatAreCroppedOut() {
        val region = ViewportMapper.fillCenterRegion(frameAspect = 0.75f, viewAspect = 0.5f) // x in 0.167..0.833
        val boxes = listOf(
            box(0.02f, 0.1f, 0.12f, 0.3f),            // far left  -> off-screen
            box(0.40f, 0.1f, 0.50f, 0.3f),            // visible
            box(0.55f, 0.5f, 0.65f, 0.7f, units = 2), // visible, merged pair
            box(0.88f, 0.1f, 0.98f, 0.3f)             // far right -> off-screen
        )
        val visible = boxes.mapNotNull { ViewportMapper.toViewBox(it, region) }
        assertEquals(2, visible.size)
        assertEquals(3, visible.sumOf { it.estimatedUnits })
    }

    // ---- fitRect / toImageNormalized (photo shown with ContentScale.Fit) ----

    @Test
    fun landscapePhotoInPortraitContainer_isLetterboxedVertically() {
        val fit = ViewportMapper.fitRect(4000f, 3000f, 1080f, 1600f)
        assertNotNull(fit)
        assertEquals(0f, fit!!.left, eps)
        assertEquals(1080f, fit.width, eps)
        assertEquals(810f, fit.height, eps)
        assertEquals(395f, fit.top, eps)
    }

    @Test
    fun portraitPhotoInWideContainer_isPillarboxedHorizontally() {
        val fit = ViewportMapper.fitRect(3000f, 4000f, 2000f, 1000f)
        assertNotNull(fit)
        assertEquals(750f, fit!!.width, eps)
        assertEquals(1000f, fit.height, eps)
        assertEquals(625f, fit.left, eps)
        assertEquals(0f, fit.top, eps)
    }

    @Test
    fun fitRect_rejectsInvalidSizes() {
        assertNull(ViewportMapper.fitRect(0f, 100f, 100f, 100f))
        assertNull(ViewportMapper.fitRect(100f, 100f, 100f, 0f))
    }

    @Test
    fun tapInsideImage_mapsToNormalizedCoordinates_andBarsAreIgnored() {
        val fit = ViewportMapper.fitRect(4000f, 3000f, 1080f, 1600f)!!
        val centre = ViewportMapper.toImageNormalized(540f, 800f, fit)
        assertNotNull(centre)
        assertEquals(0.5f, centre!!.first, eps)
        assertEquals(0.5f, centre.second, eps)

        assertNull(ViewportMapper.toImageNormalized(540f, 100f, fit))   // letter-box bar above the image
        assertNull(ViewportMapper.toImageNormalized(540f, 1500f, fit))  // letter-box bar below the image
        assertTrue(ViewportMapper.toImageNormalized(1f, 396f, fit) != null) // top-left corner of the image
    }
}
