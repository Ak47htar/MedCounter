package com.example

import com.example.vision.CountSmoother
import org.junit.Assert.assertEquals
import org.junit.Test

class CountSmootherTest {

    @Test
    fun firstValue_isReturnedAsIs() {
        assertEquals(7, CountSmoother(5).add(7))
    }

    @Test
    fun singleFrameSpike_isIgnored() {
        val s = CountSmoother(5)
        listOf(6, 6, 6, 6).forEach { s.add(it) }
        assertEquals(6, s.add(30))   // spike
        assertEquals(6, s.add(6))
    }

    @Test
    fun sustainedChange_wins_onceMostOfTheWindowAgrees() {
        val s = CountSmoother(5)
        repeat(5) { s.add(2) }
        assertEquals(2, s.add(8))   // 1 of last 5 frames says 8 -> still 2
        assertEquals(2, s.add(8))   // 2 of last 5 -> still 2
        assertEquals(8, s.add(8))   // 3 of last 5 -> the change is real
    }

    @Test
    fun reset_forgetsHistory() {
        val s = CountSmoother(5)
        repeat(5) { s.add(9) }
        s.reset()
        assertEquals(1, s.add(1))
    }

    @Test(expected = IllegalArgumentException::class)
    fun windowMustBePositive() {
        CountSmoother(0)
    }
}
