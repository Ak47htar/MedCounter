package com.example

import com.example.util.BitmapSampling
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BitmapSamplingTest {

    @Test
    fun smallImages_areNotDownsampled() {
        assertEquals(1, BitmapSampling.sampleSizeFor(800, 600, 2048))
        assertEquals(1, BitmapSampling.sampleSizeFor(2048, 1536, 2048))
    }

    @Test
    fun typicalPhoneSensors_getPowerOfTwoSampling() {
        assertEquals(2, BitmapSampling.sampleSizeFor(4000, 3000, 2048))    // 12 MP
        assertEquals(4, BitmapSampling.sampleSizeFor(8160, 6120, 2048))    // 50 MP
        assertEquals(8, BitmapSampling.sampleSizeFor(12000, 9000, 2048))   // 108 MP
        assertEquals(8, BitmapSampling.sampleSizeFor(16320, 12240, 2048))  // 200 MP
    }

    @Test
    fun resultingLongestSide_neverExceedsLimit_andResultIsPowerOfTwo() {
        for (longest in listOf(2049, 3000, 4096, 5000, 9999, 20000)) {
            val s = BitmapSampling.sampleSizeFor(longest, longest / 2, 2048)
            assertTrue("size $longest", longest / s <= 2048)
            assertTrue("power of two for $longest", s and (s - 1) == 0)
        }
    }

    @Test
    fun portraitAndLandscapeAreTreatedAlike() {
        assertEquals(
            BitmapSampling.sampleSizeFor(6000, 4000, 2048),
            BitmapSampling.sampleSizeFor(4000, 6000, 2048)
        )
    }

    @Test
    fun invalidInput_fallsBackToOne() {
        assertEquals(1, BitmapSampling.sampleSizeFor(0, 100, 2048))
        assertEquals(1, BitmapSampling.sampleSizeFor(100, -1, 2048))
        assertEquals(1, BitmapSampling.sampleSizeFor(100, 100, 0))
    }
}
