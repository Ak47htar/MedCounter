package com.example

import android.graphics.Bitmap
import com.example.data.MedicineEntity
import com.example.vision.BoxDetectionEngine
import com.example.vision.DetectedBox
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testMedicineEntityTargetProgress() {
        val med = MedicineEntity(
            id = 1,
            name = "Amoxicillin 500mg",
            unitType = "Boxes",
            currentCount = 10,
            targetCount = 20,
            incrementStep = 1
        )

        assertEquals(10, med.currentCount)
        assertEquals(20, med.targetCount)
        assertTrue(med.currentCount < med.targetCount)

        val updated = med.copy(currentCount = med.currentCount + 10)
        assertEquals(20, updated.currentCount)
        assertEquals(updated.targetCount, updated.currentCount)
    }

    @Test
    fun testDetectedBoxCoordinateNormalization() {
        val box = DetectedBox(
            id = 1,
            left = 0.2f,
            top = 0.3f,
            right = 0.6f,
            bottom = 0.7f,
            confidence = 0.9f,
            label = "Box #1",
            estimatedUnits = 2
        )

        assertEquals(0.4f, box.width, 0.001f)
        assertEquals(0.4f, box.height, 0.001f)
        assertEquals(0.4f, box.centerX, 0.001f)
        assertEquals(0.5f, box.centerY, 0.001f)
        assertTrue(box.containsNormalized(0.3f, 0.5f))
        assertFalse(box.containsNormalized(0.1f, 0.5f))
    }
}

