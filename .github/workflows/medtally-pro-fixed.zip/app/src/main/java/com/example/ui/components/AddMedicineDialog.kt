package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.MedicineEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddMedicineDialog(
    initialMedicine: MedicineEntity? = null,
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        name: String,
        dosage: String,
        unitType: String,
        itemsPerUnit: Int,
        batchNumber: String,
        expiryDate: String,
        targetCount: Int,
        incrementStep: Int,
        colorHex: String,
        notes: String
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var name by remember { mutableStateOf(initialMedicine?.name ?: "") }
    var dosage by remember { mutableStateOf(initialMedicine?.dosage ?: "") }
    var unitType by remember { mutableStateOf(initialMedicine?.unitType ?: "Boxes") }
    var itemsPerUnit by remember {
        mutableStateOf(if ((initialMedicine?.itemsPerUnit ?: 1) > 1) initialMedicine?.itemsPerUnit.toString() else "1")
    }
    var batchNumber by remember { mutableStateOf(initialMedicine?.batchNumber ?: "") }
    var expiryDate by remember { mutableStateOf(initialMedicine?.expiryDate ?: "") }
    var targetCount by remember {
        mutableStateOf(if ((initialMedicine?.targetCount ?: 0) > 0) initialMedicine?.targetCount.toString() else "")
    }
    var incrementStep by remember {
        mutableStateOf((initialMedicine?.incrementStep ?: 1).toString())
    }
    var selectedColor by remember {
        mutableStateOf(initialMedicine?.colorHex ?: "#0F766E")
    }
    var notes by remember { mutableStateOf(initialMedicine?.notes ?: "") }

    var unitDropdownExpanded by remember { mutableStateOf(false) }
    val unitOptions = listOf("Boxes", "Blister Packs", "Bottles", "Ampoules", "Strips", "Vials", "Cartons")

    val colorOptions = listOf(
        "#0F766E", // Medical Teal
        "#0284C7", // Cyan Blue
        "#059669", // Emerald
        "#7C3AED", // Royal Violet
        "#D97706", // Amber
        "#E11D48", // Rose Red
        "#475569"  // Slate
    )

    var errorMsg by remember { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        modifier = Modifier.testTag("add_medicine_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Text(
                text = if (initialMedicine == null) "Register New Medicine" else "Edit Medicine",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Configure packaging type and tracking parameters for tallying.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Medicine Name
            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    errorMsg = null
                },
                label = { Text("Medicine Name *") },
                placeholder = { Text("e.g. Amoxicillin 500mg") },
                isError = errorMsg != null && name.isBlank(),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("med_name_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Dosage
            OutlinedTextField(
                value = dosage,
                onValueChange = { dosage = it },
                label = { Text("Dosage / Form") },
                placeholder = { Text("e.g. 500mg Oral Capsules") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Unit Type Dropdown
            ExposedDropdownMenuBox(
                expanded = unitDropdownExpanded,
                onExpandedChange = { unitDropdownExpanded = !unitDropdownExpanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                OutlinedTextField(
                    value = unitType,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Packaging Unit") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = unitDropdownExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = unitDropdownExpanded,
                    onDismissRequest = { unitDropdownExpanded = false }
                ) {
                    unitOptions.forEach { opt ->
                        DropdownMenuItem(
                            text = { Text(opt) },
                            onClick = {
                                unitType = opt
                                unitDropdownExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = batchNumber,
                    onValueChange = { batchNumber = it },
                    label = { Text("Batch / Lot #") },
                    placeholder = { Text("BCH-2026-X") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = expiryDate,
                    onValueChange = { expiryDate = it },
                    label = { Text("Expiry (MM/YYYY)") },
                    placeholder = { Text("12/2027") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = targetCount,
                    onValueChange = { targetCount = it.filter { c -> c.isDigit() }.take(6) },
                    label = { Text("Target Quantity") },
                    placeholder = { Text("e.g. 25") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = incrementStep,
                    onValueChange = { incrementStep = it.filter { c -> c.isDigit() }.take(4) },
                    label = { Text("Default Step") },
                    placeholder = { Text("1") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Color tag selector
            Text(
                text = "Color Badge",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                colorOptions.forEach { hex ->
                    val c = Color(android.graphics.Color.parseColor(hex))
                    val isChosen = selectedColor.equals(hex, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(
                                width = if (isChosen) 3.dp else 1.dp,
                                color = if (isChosen) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable { selectedColor = hex }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes / Storage Location") },
                placeholder = { Text("e.g. Shelf B2, Store below 25°C") },
                maxLines = 2,
                modifier = Modifier.fillMaxWidth()
            )

            if (errorMsg != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = errorMsg ?: "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onDismiss) {
                    Text("Cancel")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (name.isBlank()) {
                            errorMsg = "Medicine name is required"
                            return@Button
                        }
                        onSave(
                            initialMedicine?.id ?: 0L,
                            name,
                            dosage,
                            unitType,
                            itemsPerUnit.toIntOrNull() ?: 1,
                            batchNumber,
                            expiryDate,
                            targetCount.toIntOrNull() ?: 0,
                            incrementStep.toIntOrNull() ?: 1,
                            selectedColor,
                            notes
                        )
                        onDismiss()
                    },
                    modifier = Modifier.testTag("save_medicine_confirm_button")
                ) {
                    Text(if (initialMedicine == null) "Create Medicine" else "Save Changes")
                }
            }
        }
    }
}
