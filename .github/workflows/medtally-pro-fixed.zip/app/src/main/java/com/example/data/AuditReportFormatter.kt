package com.example.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** Builds the plain-text audit report. Pure function so it can be unit-tested on the JVM. */
object AuditReportFormatter {

    /**
     * @param logs         entries to print, newest first
     * @param totalEntries number of entries stored; when larger than [logs] the header says so,
     *                     so a truncated export can never be mistaken for a complete one
     */
    fun format(
        logs: List<TallyLogEntity>,
        totalEntries: Int,
        generatedAt: Date = Date(),
        locale: Locale = Locale.getDefault(),
        timeZone: TimeZone = TimeZone.getDefault()
    ): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", locale).apply { this.timeZone = timeZone }
        val sb = StringBuilder()
        sb.appendLine("=========================================")
        sb.appendLine("MEDTALLY PRO - PHARMACEUTICAL AUDIT LOG")
        sb.appendLine("Generated: ${dateFormat.format(generatedAt)}")
        if (logs.size < totalEntries) {
            sb.appendLine("Entries: showing the latest ${logs.size} of $totalEntries")
        } else {
            sb.appendLine("Entries: $totalEntries")
        }
        sb.appendLine("=========================================")
        sb.appendLine()

        if (logs.isEmpty()) {
            sb.appendLine("No logs recorded.")
            return sb.toString()
        }

        for (log in logs) {
            val deltaStr = if (log.countChange > 0) "+${log.countChange}" else "${log.countChange}"
            val result = if (log.targetCount > 0) "${log.resultingCount}/${log.targetCount}" else "${log.resultingCount}"
            sb.appendLine("${dateFormat.format(Date(log.timestamp))} | ${log.medicineName}")
            sb.appendLine("  Batch: ${log.batchNumber.ifEmpty { "N/A" }} | Change: $deltaStr -> Result: $result")
            sb.appendLine("  Method: ${log.method} | Note: ${log.note}")
            sb.appendLine("-----------------------------------------")
        }
        return sb.toString()
    }
}
