package com.example.util

/** Pure helper (no Android dependencies) so it can be unit-tested on the JVM. */
object BitmapSampling {

    private const val MAX_SAMPLE_SIZE = 1 shl 10

    /**
     * Smallest power-of-two `BitmapFactory.Options.inSampleSize` for which the decoded image's
     * longest side is at most [maxSide] pixels. Never up-samples (returns 1 for small images).
     *
     * Decoding a 50-200 MP gallery photo at full size needs 200-800 MB and kills the app with an
     * OutOfMemoryError; the detector only needs a few hundred pixels anyway.
     */
    fun sampleSizeFor(width: Int, height: Int, maxSide: Int): Int {
        if (width <= 0 || height <= 0 || maxSide <= 0) return 1
        val longest = maxOf(width, height)
        var sample = 1
        while (longest / sample > maxSide && sample < MAX_SAMPLE_SIZE) sample *= 2
        return sample
    }
}
