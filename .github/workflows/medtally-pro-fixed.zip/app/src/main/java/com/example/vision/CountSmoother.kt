package com.example.vision

/**
 * Median filter over the last [windowSize] per-frame counts.
 *
 * Every camera frame is analysed independently, so the raw count flickers (6, 7, 6, 8, 6 ...).
 * The "ADD +N TO TALLY" button adds whatever number is on screen at the moment of the tap, so a
 * one-frame spike used to end up in the inventory. The median ignores such spikes.
 *
 * Thread-safe: frames arrive on the camera thread, [reset] is called from the UI thread.
 */
class CountSmoother(private val windowSize: Int = 5) {

    init {
        require(windowSize >= 1) { "windowSize must be >= 1" }
    }

    private val window = IntArray(windowSize)
    private var filled = 0
    private var next = 0

    @Synchronized
    fun add(count: Int): Int {
        window[next] = count
        next = (next + 1) % windowSize
        if (filled < windowSize) filled++
        val sorted = window.copyOf(filled).also { it.sort() }
        return sorted[filled / 2]
    }

    @Synchronized
    fun reset() {
        filled = 0
        next = 0
    }
}
