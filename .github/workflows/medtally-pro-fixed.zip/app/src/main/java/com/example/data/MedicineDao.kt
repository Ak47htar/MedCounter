package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicineDao {
    @Query("SELECT * FROM medicines ORDER BY updatedAt DESC, id ASC")
    fun getAllMedicines(): Flow<List<MedicineEntity>>

    @Query("SELECT * FROM medicines WHERE id = :id LIMIT 1")
    suspend fun getMedicineById(id: Long): MedicineEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(medicine: MedicineEntity): Long

    @Update
    suspend fun updateMedicine(medicine: MedicineEntity)

    @Delete
    suspend fun deleteMedicine(medicine: MedicineEntity)

    @Query("UPDATE medicines SET currentCount = :count, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateCount(id: Long, count: Int, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE medicines SET targetCount = :target WHERE id = :id")
    suspend fun updateTarget(id: Long, target: Int)

    @Query("UPDATE medicines SET incrementStep = :step WHERE id = :id")
    suspend fun updateStep(id: Long, step: Int)

    @Query("SELECT COUNT(*) FROM medicines")
    suspend fun getCount(): Int
}
