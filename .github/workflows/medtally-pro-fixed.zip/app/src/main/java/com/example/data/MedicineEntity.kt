package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicines")
data class MedicineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val dosage: String = "",
    val unitType: String = "Boxes", // "Boxes", "Blister Packs", "Bottles", "Ampoules", "Strips"
    val itemsPerUnit: Int = 1, // e.g. 10 strips per box, or 30 pills per bottle
    val batchNumber: String = "",
    val expiryDate: String = "",
    val currentCount: Int = 0,
    val targetCount: Int = 0,
    val incrementStep: Int = 1,
    val colorHex: String = "#0F766E",
    val notes: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)
