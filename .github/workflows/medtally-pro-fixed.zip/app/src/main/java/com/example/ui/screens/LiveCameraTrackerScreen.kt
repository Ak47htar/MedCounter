package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.net.Uri
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.MedicineEntity
import com.example.util.BitmapLoader
import com.example.ui.theme.MedHudCyan
import com.example.ui.theme.MedHudGreen
import com.example.ui.viewmodel.TallyViewModel
import com.example.vision.BoxDetectionEngine
import com.example.vision.DetectedBox
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

@Composable
fun LiveCameraTrackerScreen(
    viewModel: TallyViewModel,
    activeMedicine: MedicineEntity?,
    onNavigateBack: () -> Unit,
    onNavigateToPhotoInspection: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val detectedBoxes by viewModel.liveDetectedBoxes.collectAsState()
    val totalCount by viewModel.liveTotalCount.collectAsState()
    val torchEnabled by viewModel.cameraTorchEnabled.collectAsState()
    val sensitivity by viewModel.cameraSensitivity.collectAsState()
    val packagingFilter by viewModel.packagingFilter.collectAsState()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Pick up a permission the user granted in system settings while the app was in the background.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasCameraPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    var cameraControl by remember { mutableStateOf<androidx.camera.core.CameraControl?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var isCapturing by remember { mutableStateOf(false) }

    // Keyed on cameraControl too: the control only exists once the camera is bound, so the torch
    // state kept in the ViewModel is (re)applied as soon as the camera is ready. Before, the effect
    // ran once, found no camera yet, and the torch icon could show "on" while the torch was off.
    LaunchedEffect(cameraControl, torchEnabled) {
        cameraControl?.enableTorch(torchEnabled)
    }

    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val mainExecutor = remember { ContextCompat.getMainExecutor(context) }
    val session = remember { CameraSession() }

    DisposableEffect(Unit) {
        viewModel.clearLiveDetection()
        onDispose {
            session.disposed = true
            // bindToLifecycle() ties the camera to the *Activity*, so merely leaving this screen did
            // not release it: the camera (and torch) kept running behind the other tabs until the
            // whole app went to the background. Release it explicitly.
            session.provider?.unbindAll()
            viewModel.setCameraTorch(false)
            viewModel.setViewportAspect(0f)
            // Clear the last result on the analyzer thread, i.e. after any frame still being
            // processed, so a late frame cannot bring stale boxes / a stale count back.
            try {
                cameraExecutor.execute { viewModel.clearLiveDetection() }
            } catch (_: RejectedExecutionException) {
                viewModel.clearLiveDetection()
            }
            cameraExecutor.shutdown()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { size ->
                if (size.height > 0) viewModel.setViewportAspect(size.width.toFloat() / size.height)
            }
            .testTag("live_camera_screen")
    ) {
        if (hasCameraPermission) {
            // Camera Preview View
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        scaleType = PreviewView.ScaleType.FILL_CENTER
                    }

                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                    cameraProviderFuture.addListener({
                        // The screen may have been left before the camera provider became ready.
                        if (session.disposed) return@addListener
                        val cameraProvider = try {
                            cameraProviderFuture.get()
                        } catch (_: Exception) {
                            return@addListener
                        }
                        session.provider = cameraProvider
                        val preview = Preview.Builder().build().also {
                            it.setSurfaceProvider(previewView.surfaceProvider)
                        }

                        val capture = ImageCapture.Builder()
                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                            .build()
                        imageCapture = capture

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                            .build()

                        imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                            try {
                                if (!session.disposed) {
                                    val result = BoxDetectionEngine.analyzeCameraFrame(
                                        imageProxy = imageProxy,
                                        sensitivity = sensitivity,
                                        packagingType = packagingFilter
                                    )
                                    if (!session.disposed) viewModel.updateLiveDetection(result)
                                }
                            } finally {
                                imageProxy.close()
                            }
                        }

                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                        try {
                            cameraProvider.unbindAll()
                            val cam = cameraProvider.bindToLifecycle(
                                lifecycleOwner,
                                cameraSelector,
                                preview,
                                capture,
                                imageAnalysis
                            )
                            cameraControl = cam.cameraControl
                        } catch (_: Exception) {}
                    }, ContextCompat.getMainExecutor(ctx))

                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )

            // Neon HUD Canvas Overlay tracking detected boxes
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("box_hud_overlay_canvas")
            ) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                for (box in detectedBoxes) {
                    val rectLeft = box.left * canvasWidth
                    val rectTop = box.top * canvasHeight
                    val rectRight = box.right * canvasWidth
                    val rectBottom = box.bottom * canvasHeight
                    val boxW = rectRight - rectLeft
                    val boxH = rectBottom - rectTop

                    // Draw semi-transparent cyan background
                    drawRect(
                        color = MedHudCyan.copy(alpha = 0.12f),
                        topLeft = Offset(rectLeft, rectTop),
                        size = Size(boxW, boxH)
                    )

                    // Draw dashed / crisp neon bounding box
                    drawRect(
                        color = MedHudGreen,
                        topLeft = Offset(rectLeft, rectTop),
                        size = Size(boxW, boxH),
                        style = Stroke(width = 3.dp.toPx())
                    )

                    // Draw corner brackets
                    val cornerLen = minOf(boxW, boxH) * 0.22f
                    // Top-Left
                    drawLine(MedHudGreen, Offset(rectLeft - 2, rectTop), Offset(rectLeft + cornerLen, rectTop), 6f)
                    drawLine(MedHudGreen, Offset(rectLeft, rectTop - 2), Offset(rectLeft, rectTop + cornerLen), 6f)
                    // Top-Right
                    drawLine(MedHudGreen, Offset(rectRight + 2, rectTop), Offset(rectRight - cornerLen, rectTop), 6f)
                    drawLine(MedHudGreen, Offset(rectRight, rectTop - 2), Offset(rectRight, rectTop + cornerLen), 6f)
                    // Bottom-Left
                    drawLine(MedHudGreen, Offset(rectLeft - 2, rectBottom), Offset(rectLeft + cornerLen, rectBottom), 6f)
                    drawLine(MedHudGreen, Offset(rectLeft, rectBottom + 2), Offset(rectLeft, rectBottom - cornerLen), 6f)
                    // Bottom-Right
                    drawLine(MedHudGreen, Offset(rectRight + 2, rectBottom), Offset(rectRight - cornerLen, rectBottom), 6f)
                    drawLine(MedHudGreen, Offset(rectRight, rectBottom + 2), Offset(rectRight, rectBottom - cornerLen), 6f)

                    // Center dot
                    drawCircle(
                        color = MedHudGreen,
                        radius = 4.dp.toPx(),
                        center = Offset(rectLeft + boxW / 2f, rectTop + boxH / 2f)
                    )
                }
            }
        } else {
            // Permission request UI
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Camera Permission Required",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "MedTally Pro requires camera access to track and count medicine boxes in real time.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.8f)
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) }) {
                    Text("Grant Permission")
                }
                Spacer(modifier = Modifier.height(8.dp))
                // After "Don't ask again" Android no longer shows the permission dialog, so offer
                // a way to enable the camera from the system settings.
                TextButton(onClick = { openAppSettings(context) }) {
                    Text("Open App Settings", color = Color.White.copy(alpha = 0.85f))
                }
            }
        }

        // Top HUD Header Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.6f),
                    modifier = Modifier.size(44.dp)
                ) {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("camera_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to tally",
                            tint = Color.White
                        )
                    }
                }

                // Active Medicine & Count Status Badge
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MedHudGreen.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(MedHudGreen)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = activeMedicine?.name ?: "All Medicines",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                color = Color.White,
                                maxLines = 1
                            )
                            Text(
                                text = "Current: ${activeMedicine?.currentCount ?: 0} ${activeMedicine?.unitType ?: "Boxes"}" +
                                        if ((activeMedicine?.targetCount ?: 0) > 0) " (Target: ${activeMedicine?.targetCount})" else "",
                                style = MaterialTheme.typography.labelSmall,
                                color = MedHudGreen
                            )
                        }
                    }
                }

                // Torch and Tune Controls
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.6f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.toggleCameraTorch() },
                            modifier = Modifier.testTag("camera_torch_button")
                        ) {
                            Icon(
                                imageVector = if (torchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                contentDescription = "Toggle Torch",
                                tint = if (torchEnabled) Color.Yellow else Color.White
                            )
                        }
                    }

                    Surface(
                        shape = CircleShape,
                        color = Color.Black.copy(alpha = 0.6f),
                        modifier = Modifier.size(44.dp)
                    ) {
                        IconButton(
                            onClick = { showSettingsSheet = !showSettingsSheet },
                            modifier = Modifier.testTag("camera_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Tracking Settings",
                                tint = if (showSettingsSheet) MedHudGreen else Color.White
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Real-time Detection HUD Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MedHudCyan.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (totalCount == 0) "Looking for ${packagingFilter.name.lowercase()}..." else "TRACKING: $totalCount ${activeMedicine?.unitType ?: "BOXES"} IN VIEW",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = if (totalCount > 0) MedHudGreen else Color.White.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        // Live Camera Settings / Tuning Drawer
        AnimatedVisibility(
            visible = showSettingsSheet,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 110.dp, start = 16.dp, end = 16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xEE111827)),
                border = androidx.compose.foundation.BorderStroke(1.dp, MedHudCyan.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Camera Tracking Calibration",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Package Type:",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BoxDetectionEngine.PackagingType.values().forEach { type ->
                            val isSelected = packagingFilter == type
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) MedHudGreen else Color.White.copy(alpha = 0.15f),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.setPackagingFilter(type) }
                            ) {
                                Text(
                                    text = type.name.replace("_", " "),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ),
                                    color = if (isSelected) Color.Black else Color.White,
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Contrast Sensitivity: ${(sensitivity * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                    Slider(
                        value = sensitivity,
                        onValueChange = { viewModel.setCameraSensitivity(it) },
                        valueRange = 0.1f..0.9f
                    )
                }
            }
        }

        // Bottom Action Bar: Add Detected Count, Freeze / Photo Capture
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding(),
            color = Color.Black.copy(alpha = 0.85f),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Snap & Inspect Frame button
                    OutlinedButton(
                        onClick = {
                            val capture = imageCapture ?: return@OutlinedButton
                            isCapturing = true
                            capture.takePicture(
                                cameraExecutor,
                                object : ImageCapture.OnImageCapturedCallback() {
                                    override fun onCaptureSuccess(image: ImageProxy) {
                                        // JPEG decoding is slow: do it on the camera thread instead of freezing the UI.
                                        val bitmap = try {
                                            imageProxyToBitmap(image)
                                        } finally {
                                            image.close()
                                        }
                                        mainExecutor.execute {
                                            isCapturing = false
                                            if (session.disposed) return@execute // user already left the screen
                                            if (bitmap != null) {
                                                viewModel.setCapturedPhoto(bitmap)
                                                onNavigateToPhotoInspection()
                                            } else {
                                                Toast.makeText(
                                                    context,
                                                    "Couldn't process the photo. Please try again.",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        }
                                    }

                                    override fun onError(exception: ImageCaptureException) {
                                        mainExecutor.execute {
                                            isCapturing = false
                                            Toast.makeText(
                                                context,
                                                "Couldn't capture the photo. Please try again.",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        }
                                    }
                                }
                            )
                        },
                        enabled = !isCapturing && imageCapture != null,
                        modifier = Modifier
                            .height(54.dp)
                            .testTag("freeze_frame_button"),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.White.copy(alpha = 0.6f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "Capture Frame",
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Freeze Photo",
                            color = Color.White,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }

                    // Primary Add Tracked Boxes to Tally Button
                    Button(
                        onClick = {
                            if (totalCount > 0) {
                                viewModel.addDetectedCountToActive(
                                    countToAdd = totalCount,
                                    sourceMethod = "LIVE_CAMERA_TRACK",
                                    detailNote = "Live camera recognized $totalCount ${activeMedicine?.unitType ?: "boxes"}"
                                )
                                onNavigateBack()
                            }
                        },
                        enabled = totalCount > 0 && activeMedicine != null,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("add_tracked_boxes_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MedHudGreen,
                            contentColor = Color(0xFF042F2E),
                            disabledContainerColor = Color.White.copy(alpha = 0.2f),
                            disabledContentColor = Color.White.copy(alpha = 0.5f)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add boxes",
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when {
                                activeMedicine == null -> "ADD A MEDICINE FIRST"
                                totalCount > 0 -> "ADD +$totalCount TO TALLY"
                                else -> "NO BOXES FOUND"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Converts a CameraX ImageCapture result into an upright bitmap.
 *
 * ImageCapture delivers a JPEG: one plane holding the *compressed file*, not raw NV21 pixels. The old
 * code fed those JPEG bytes to YuvImage as if they were NV21, so "Freeze Photo" produced a garbage
 * picture (or crashed natively).
 */
private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
    return try {
        val rotation = image.imageInfo.rotationDegrees
        if (image.format == ImageFormat.JPEG) {
            val buffer = image.planes[0].buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            BitmapLoader.decodeJpegBytes(bytes, rotation)
        } else {
            // Unexpected format: let CameraX convert it (JPEG / YUV_420_888 / RGBA_8888), then rotate.
            BitmapLoader.rotate(image.toBitmap(), rotation)
        }
    } catch (_: Exception) {
        null
    } catch (_: OutOfMemoryError) {
        null
    }
}

/** What the screen's onDispose needs to release the camera, plus a flag for "screen already left". */
private class CameraSession {
    @Volatile
    var disposed: Boolean = false
    var provider: ProcessCameraProvider? = null
}

private fun openAppSettings(context: Context) {
    val intent = Intent(
        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.fromParts("package", context.packageName, null)
    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        // No settings app available - nothing else to do.
    }
}
