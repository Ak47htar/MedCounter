package com.example.vision

import kotlin.math.min

/**
 * Pure geometry helpers that map detection results (normalised to the camera frame or to a bitmap)
 * onto what is actually visible on screen.
 *
 * Why this exists: boxes are detected on the *whole* frame/bitmap, but the screen shows only part of
 * the frame (camera preview is centre-cropped to fill the screen) or shows the bitmap letter-boxed
 * (ContentScale.Fit). Drawing `box.left * canvasWidth` therefore put every box in the wrong place.
 */
object ViewportMapper {

    /** The visible part of a frame, in frame-normalised coordinates (0..1). */
    data class Region(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val width: Float get() = right - left
        val height: Float get() = bottom - top

        companion object {
            val FULL = Region(0f, 0f, 1f, 1f)
        }
    }

    /** Where an image is drawn when scaled to fit inside a container, in container pixels. */
    data class FitRect(val left: Float, val top: Float, val width: Float, val height: Float)

    /**
     * Visible part of a frame that is scaled to *fill* a view and centre-cropped
     * (CameraX PreviewView.ScaleType.FILL_CENTER).
     *
     * @param frameAspect upright frame width / height (0 or invalid = unknown -> whole frame)
     * @param viewAspect  view width / height        (0 or invalid = unknown -> whole frame)
     */
    fun fillCenterRegion(frameAspect: Float, viewAspect: Float): Region {
        if (!frameAspect.isUsable() || !viewAspect.isUsable()) return Region.FULL
        return when {
            viewAspect < frameAspect -> {
                // View is narrower than the frame: left/right edges of the frame are cropped away.
                val offset = (1f - viewAspect / frameAspect) / 2f
                Region(offset, 0f, 1f - offset, 1f)
            }
            viewAspect > frameAspect -> {
                // View is wider than the frame: top/bottom edges are cropped away.
                val offset = (1f - frameAspect / viewAspect) / 2f
                Region(0f, offset, 1f, 1f - offset)
            }
            else -> Region.FULL
        }
    }

    /**
     * Converts a frame-normalised box into view-normalised coordinates.
     * Returns null when the box centre lies outside the visible [region] (the user cannot see that
     * item, so it must not be drawn or counted). Boxes that stick out of the view are clipped.
     */
    fun toViewBox(box: DetectedBox, region: Region): DetectedBox? {
        if (region.width <= 0f || region.height <= 0f) return null
        val cx = (box.left + box.right) / 2f
        val cy = (box.top + box.bottom) / 2f
        if (cx < region.left || cx > region.right || cy < region.top || cy > region.bottom) return null
        return box.copy(
            left = ((box.left - region.left) / region.width).coerceIn(0f, 1f),
            top = ((box.top - region.top) / region.height).coerceIn(0f, 1f),
            right = ((box.right - region.left) / region.width).coerceIn(0f, 1f),
            bottom = ((box.bottom - region.top) / region.height).coerceIn(0f, 1f)
        )
    }

    /** Rectangle an image occupies inside a container with ContentScale.Fit (centred). Null if sizes are invalid. */
    fun fitRect(
        contentWidth: Float,
        contentHeight: Float,
        containerWidth: Float,
        containerHeight: Float
    ): FitRect? {
        if (contentWidth <= 0f || contentHeight <= 0f || containerWidth <= 0f || containerHeight <= 0f) return null
        val scale = min(containerWidth / contentWidth, containerHeight / contentHeight)
        val w = contentWidth * scale
        val h = contentHeight * scale
        return FitRect(
            left = (containerWidth - w) / 2f,
            top = (containerHeight - h) / 2f,
            width = w,
            height = h
        )
    }

    /**
     * Converts a point in container pixels to image-normalised coordinates (0..1).
     * Returns null when the point is outside the drawn image (e.g. in the letter-box bars).
     */
    fun toImageNormalized(x: Float, y: Float, rect: FitRect): Pair<Float, Float>? {
        if (rect.width <= 0f || rect.height <= 0f) return null
        val nx = (x - rect.left) / rect.width
        val ny = (y - rect.top) / rect.height
        if (nx < 0f || nx > 1f || ny < 0f || ny > 1f) return null
        return nx to ny
    }

    private fun Float.isUsable(): Boolean = this > 0f && !this.isNaN() && !this.isInfinite()
}
