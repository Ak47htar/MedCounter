package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TallyLogDao {
    @Query("SELECT * FROM tally_logs ORDER BY timestamp DESC, id DESC LIMIT 200")
    fun getAllLogs(): Flow<List<TallyLogEntity>>

    /** Newest-first entries for the exported audit report (the on-screen list is capped at 200). */
    @Query("SELECT * FROM tally_logs ORDER BY timestamp DESC, id DESC LIMIT :limit")
    suspend fun getRecentLogs(limit: Int): List<TallyLogEntity>

    @Query("SELECT COUNT(*) FROM tally_logs")
    suspend fun getLogCount(): Int

    @Query("SELECT * FROM tally_logs WHERE medicineId = :medicineId ORDER BY timestamp DESC LIMIT 50")
    fun getLogsForMedicine(medicineId: Long): Flow<List<TallyLogEntity>>

    @Insert
    suspend fun insertLog(log: TallyLogEntity): Long

    @Query("DELETE FROM tally_logs")
    suspend fun clearLogs()
}
