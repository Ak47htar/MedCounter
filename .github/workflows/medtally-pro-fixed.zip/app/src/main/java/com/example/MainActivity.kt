package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Medication
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material.icons.outlined.Videocam
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import com.example.ui.screens.AuditLogScreen
import com.example.ui.screens.LiveCameraTrackerScreen
import com.example.ui.screens.MedicineInventoryScreen
import com.example.ui.screens.PhotoInspectionScreen
import com.example.ui.screens.TallyCounterScreen
import com.example.ui.theme.MedTallyTheme
import com.example.ui.viewmodel.TallyViewModel

enum class AppDestination(val label: String) {
    COUNTER("Counter"),
    LIVE_TRACKER("Live Camera"),
    PHOTO_SCAN("Photo Scan"),
    MEDICINES("Medicines"),
    LOGS("Audit Log")
}

class MainActivity : ComponentActivity() {

    private val viewModel: TallyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MedTallyTheme {
                MainAppScaffold(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppScaffold(viewModel: TallyViewModel) {
    var currentDestination by rememberSaveable { mutableStateOf(AppDestination.COUNTER) }
    val activeMedicine by viewModel.activeMedicine.collectAsState()

    // Handle back button when inside secondary screens
    if (currentDestination != AppDestination.COUNTER) {
        BackHandler {
            currentDestination = AppDestination.COUNTER
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Only show bottom navigation when not in live full-screen camera mode
            if (currentDestination != AppDestination.LIVE_TRACKER) {
                NavigationBar(
                    modifier = Modifier.testTag("main_navigation_bar"),
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    AppDestination.values().forEach { destination ->
                        val isSelected = currentDestination == destination
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentDestination = destination },
                            icon = {
                                val icon = when (destination) {
                                    AppDestination.COUNTER -> if (isSelected) Icons.Filled.TouchApp else Icons.Outlined.TouchApp
                                    AppDestination.LIVE_TRACKER -> if (isSelected) Icons.Filled.Videocam else Icons.Outlined.Videocam
                                    AppDestination.PHOTO_SCAN -> if (isSelected) Icons.Filled.PhotoCamera else Icons.Outlined.PhotoCamera
                                    AppDestination.MEDICINES -> if (isSelected) Icons.Filled.Medication else Icons.Outlined.Medication
                                    AppDestination.LOGS -> if (isSelected) Icons.Filled.History else Icons.Outlined.History
                                }
                                Icon(imageVector = icon, contentDescription = destination.label)
                            },
                            label = { Text(destination.label) },
                            modifier = Modifier.testTag("nav_item_${destination.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        when (currentDestination) {
            AppDestination.COUNTER -> {
                TallyCounterScreen(
                    viewModel = viewModel,
                    onOpenLiveCamera = { currentDestination = AppDestination.LIVE_TRACKER },
                    onOpenPhotoScanner = { currentDestination = AppDestination.PHOTO_SCAN },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            AppDestination.LIVE_TRACKER -> {
                LiveCameraTrackerScreen(
                    viewModel = viewModel,
                    activeMedicine = activeMedicine,
                    onNavigateBack = { currentDestination = AppDestination.COUNTER },
                    onNavigateToPhotoInspection = { currentDestination = AppDestination.PHOTO_SCAN }
                )
            }
            AppDestination.PHOTO_SCAN -> {
                PhotoInspectionScreen(
                    viewModel = viewModel,
                    activeMedicine = activeMedicine,
                    onNavigateBack = { currentDestination = AppDestination.COUNTER },
                    onOpenLiveCamera = { currentDestination = AppDestination.LIVE_TRACKER },
                    // This screen applies its own statusBarsPadding()/navigationBarsPadding(); tell it
                    // the Scaffold already handled those insets so they are not added a second time.
                    modifier = Modifier.padding(innerPadding).consumeWindowInsets(innerPadding)
                )
            }
            AppDestination.MEDICINES -> {
                MedicineInventoryScreen(
                    viewModel = viewModel,
                    onSelectAndCount = { medId ->
                        viewModel.selectMedicine(medId)
                        currentDestination = AppDestination.COUNTER
                    },
                    modifier = Modifier.padding(innerPadding)
                )
            }
            AppDestination.LOGS -> {
                AuditLogScreen(
                    viewModel = viewModel,
                    modifier = Modifier.padding(innerPadding)
                )
            }
        }
    }
}
