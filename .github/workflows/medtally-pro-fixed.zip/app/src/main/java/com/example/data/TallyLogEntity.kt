package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tally_logs")
data class TallyLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val medicineId: Long,
    val medicineName: String,
    val batchNumber: String = "",
    val countChange: Int, // e.g. +1, +5, +12, or -1
    val resultingCount: Int,
    val targetCount: Int = 0,
    val method: String, // "MANUAL_TAP", "LIVE_CAMERA_TRACK", "PHOTO_SCAN", "RESET"
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
