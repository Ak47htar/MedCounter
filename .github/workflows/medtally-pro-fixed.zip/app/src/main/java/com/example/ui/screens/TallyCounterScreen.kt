package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.AddMedicineDialog
import com.example.ui.components.MedicineSelectorRow
import com.example.ui.components.TactileCounterWidget
import com.example.ui.viewmodel.TallyViewModel

@Composable
fun TallyCounterScreen(
    viewModel: TallyViewModel,
    onOpenLiveCamera: () -> Unit,
    onOpenPhotoScanner: () -> Unit,
    modifier: Modifier = Modifier
) {
    val medicines by viewModel.allMedicines.collectAsState()
    val activeMedicine by viewModel.activeMedicine.collectAsState()
    val selectedId by viewModel.selectedMedicineId.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }
    var showAddMedicineDialog by remember { mutableStateOf(false) }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusMessage()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("tally_counter_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp)
        ) {
            // Header Bar
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "MedTally Pro",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Pharmaceutical Medicine & Box Counter",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Medicine Selector Tabs
            MedicineSelectorRow(
                medicines = medicines,
                selectedId = activeMedicine?.id ?: selectedId,
                onSelectMedicine = { viewModel.selectMedicine(it) },
                onAddNewMedicine = { showAddMedicineDialog = true }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Main Tactile Counter
            if (activeMedicine != null) {
                TactileCounterWidget(
                    medicine = activeMedicine!!,
                    onIncrement = { customStep -> viewModel.incrementActive(customStep) },
                    onDecrement = { viewModel.decrementActive() },
                    onReset = { viewModel.resetActive() },
                    onSetStep = { viewModel.setStep(it) },
                    onSetTarget = { viewModel.setTarget(it) },
                    onOpenLiveCamera = onOpenLiveCamera,
                    onOpenPhotoScanner = onOpenPhotoScanner
                )
            } else {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = MaterialTheme.shapes.medium
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No medicine selected",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Add a medicine above to start tallying.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(16.dp)
        )
    }

    if (showAddMedicineDialog) {
        AddMedicineDialog(
            initialMedicine = null,
            onDismiss = { showAddMedicineDialog = false },
            onSave = { id, name, dosage, unitType, itemsPerUnit, batch, expiry, target, step, color, notes ->
                viewModel.saveMedicine(
                    id = id,
                    name = name,
                    dosage = dosage,
                    unitType = unitType,
                    itemsPerUnit = itemsPerUnit,
                    batchNumber = batch,
                    expiryDate = expiry,
                    targetCount = target,
                    incrementStep = step,
                    colorHex = color,
                    notes = notes
                )
            }
        )
    }
}
