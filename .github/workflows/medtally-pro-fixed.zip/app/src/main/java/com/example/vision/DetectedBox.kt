package com.example.vision

import android.graphics.RectF

data class DetectedBox(
    val id: Int,
    val left: Float, // Normalized 0f..1f
    val top: Float, // Normalized 0f..1f
    val right: Float, // Normalized 0f..1f
    val bottom: Float, // Normalized 0f..1f
    val confidence: Float = 0.85f,
    val label: String = "Box",
    val estimatedUnits: Int = 1,
    val isSelected: Boolean = true
) {
    val width: Float get() = (right - left).coerceAtLeast(0.01f)
    val height: Float get() = (bottom - top).coerceAtLeast(0.01f)
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val aspectRatio: Float get() = width / height

    fun toRectF(viewWidth: Float, viewHeight: Float): RectF {
        return RectF(
            left * viewWidth,
            top * viewHeight,
            right * viewWidth,
            bottom * viewHeight
        )
    }

    fun containsNormalized(x: Float, y: Float): Boolean {
        return x in left..right && y in top..bottom
    }
}
