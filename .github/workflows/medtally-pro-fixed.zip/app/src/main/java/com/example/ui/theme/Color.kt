package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Medical Palette
val MedTealPrimary = Color(0xFF0F766E)
val MedTealOnPrimary = Color(0xFFFFFFFF)
val MedTealContainer = Color(0xFFCCFBF1)
val MedTealOnContainer = Color(0xFF115E59)

val MedCyanSecondary = Color(0xFF0284C7)
val MedCyanOnSecondary = Color(0xFFFFFFFF)
val MedCyanContainer = Color(0xFFE0F2FE)
val MedCyanOnContainer = Color(0xFF0369A1)

val MedEmeraldTertiary = Color(0xFF059669)
val MedEmeraldOnTertiary = Color(0xFFFFFFFF)

// Surface & Backgrounds (Clean, Clinical)
val MedBackgroundLight = Color(0xFFF8FAFC)
val MedSurfaceLight = Color(0xFFFFFFFF)
val MedSurfaceVariantLight = Color(0xFFF1F5F9)
val MedOnSurfaceLight = Color(0xFF0F172A)
val MedOutlineLight = Color(0xFFCBD5E1)

// Dark Theme Variants
val MedTealDark = Color(0xFF2DD4BF)
val MedTealContainerDark = Color(0xFF134E4A)
val MedBackgroundDark = Color(0xFF0B1315)
val MedSurfaceDark = Color(0xFF132225)
val MedSurfaceVariantDark = Color(0xFF1A2F33)
val MedOnSurfaceDark = Color(0xFFE2E8F0)
val MedOutlineDark = Color(0xFF2D4B50)

// Operational Alert Colors
val MedWarningAmber = Color(0xFFD97706)
val MedSuccessGreen = Color(0xFF16A34A)
val MedDangerRed = Color(0xFFDC2626)
val MedHudGreen = Color(0xFF00FF9D)
val MedHudCyan = Color(0xFF00E5FF)
