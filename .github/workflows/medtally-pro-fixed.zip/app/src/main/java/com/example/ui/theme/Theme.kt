package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = MedTealDark,
    onPrimary = Color(0xFF042F2E),
    primaryContainer = MedTealContainerDark,
    onPrimaryContainer = Color(0xFFCCFBF1),
    secondary = MedCyanSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF075985),
    onSecondaryContainer = Color(0xFFE0F2FE),
    tertiary = MedEmeraldTertiary,
    background = MedBackgroundDark,
    surface = MedSurfaceDark,
    surfaceVariant = MedSurfaceVariantDark,
    onSurface = MedOnSurfaceDark,
    outline = MedOutlineDark
)

private val LightColorScheme = lightColorScheme(
    primary = MedTealPrimary,
    onPrimary = MedTealOnPrimary,
    primaryContainer = MedTealContainer,
    onPrimaryContainer = MedTealOnContainer,
    secondary = MedCyanSecondary,
    onSecondary = MedCyanOnSecondary,
    secondaryContainer = MedCyanContainer,
    onSecondaryContainer = MedCyanOnContainer,
    tertiary = MedEmeraldTertiary,
    background = MedBackgroundLight,
    surface = MedSurfaceLight,
    surfaceVariant = MedSurfaceVariantLight,
    onSurface = MedOnSurfaceLight,
    outline = MedOutlineLight
)

@Composable
fun MedTallyTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep clean medical brand colors consistent
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
