package com.example.ui.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AuditReportFormatter
import com.example.data.MedicineEntity
import com.example.data.MedicineRepository
import com.example.data.TallyLogEntity
import com.example.util.HapticFeedbackHelper
import com.example.vision.BoxDetectionEngine
import com.example.vision.CountSmoother
import com.example.vision.DetectedBox
import com.example.vision.ViewportMapper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class TallyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MedicineRepository = MedicineRepository(AppDatabase.getDatabase(application))
    val haptic = HapticFeedbackHelper(application)

    // Most recently counted first. Only used to pick a sensible default selection.
    private val medicinesByRecency: StateFlow<List<MedicineEntity>> = repository.allMedicines
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Lists shown in the UI use a stable alphabetical order. Sorting by "last updated" made the
    // medicine tabs and cards jump to the front every time you tapped the counter.
    val allMedicines: StateFlow<List<MedicineEntity>> = medicinesByRecency
        .map { list -> list.sortedWith(compareBy<MedicineEntity>({ it.name.lowercase() }, { it.id })) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val allLogs: StateFlow<List<TallyLogEntity>> = repository.allLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _selectedMedicineId = MutableStateFlow<Long?>(null)
    val selectedMedicineId: StateFlow<Long?> = _selectedMedicineId.asStateFlow()

    val activeMedicine: StateFlow<MedicineEntity?> = combine(
        medicinesByRecency,
        _selectedMedicineId
    ) { medicines, selectedId ->
        if (medicines.isEmpty()) return@combine null
        val match = medicines.find { it.id == selectedId }
        match ?: medicines.firstOrNull()
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null
    )

    // Camera and Vision States
    private val _liveDetectedBoxes = MutableStateFlow<List<DetectedBox>>(emptyList())
    val liveDetectedBoxes: StateFlow<List<DetectedBox>> = _liveDetectedBoxes.asStateFlow()

    private val _liveTotalCount = MutableStateFlow(0)
    val liveTotalCount: StateFlow<Int> = _liveTotalCount.asStateFlow()

    private val _cameraTorchEnabled = MutableStateFlow(false)
    val cameraTorchEnabled: StateFlow<Boolean> = _cameraTorchEnabled.asStateFlow()

    private val _cameraSensitivity = MutableStateFlow(0.5f)
    val cameraSensitivity: StateFlow<Float> = _cameraSensitivity.asStateFlow()

    private val _packagingFilter = MutableStateFlow(BoxDetectionEngine.PackagingType.BOXES)
    val packagingFilter: StateFlow<BoxDetectionEngine.PackagingType> = _packagingFilter.asStateFlow()

    // Width / height of the camera view on screen (reported by the screen; 0 = unknown).
    @Volatile
    private var viewportAspect: Float = 0f
    private val countSmoother = CountSmoother(LIVE_COUNT_WINDOW)

    // Captured Photo Inspection State
    private val _capturedPhotoBitmap = MutableStateFlow<Bitmap?>(null)
    val capturedPhotoBitmap: StateFlow<Bitmap?> = _capturedPhotoBitmap.asStateFlow()

    private val _photoDetectedBoxes = MutableStateFlow<List<DetectedBox>>(emptyList())
    val photoDetectedBoxes: StateFlow<List<DetectedBox>> = _photoDetectedBoxes.asStateFlow()

    private var photoAnalysisJob: Job? = null

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun selectMedicine(id: Long) {
        _selectedMedicineId.value = id
    }

    fun incrementActive(customStep: Int? = null) {
        val med = activeMedicine.value ?: return
        val step = customStep ?: med.incrementStep
        val expectedCount = med.currentCount.toLong() + step

        // Haptic feedback logic (based on the on-screen value; the stored value is updated atomically below)
        if (med.targetCount > 0 && med.currentCount < med.targetCount && expectedCount >= med.targetCount) {
            haptic.targetReached()
        } else if (med.targetCount > 0 && expectedCount > med.targetCount) {
            haptic.overTargetAlert()
        } else if (step > 1) {
            haptic.stepAdd()
        } else {
            haptic.tick()
        }

        viewModelScope.launch(Dispatchers.IO) {
            repository.adjustCount(
                medicineId = med.id,
                delta = step,
                method = "MANUAL_TAP",
                note = "+$step ${med.unitType}"
            )
        }
    }

    fun decrementActive() {
        val med = activeMedicine.value ?: return
        if (med.currentCount <= 0) return
        haptic.tick()

        viewModelScope.launch(Dispatchers.IO) {
            repository.adjustCount(
                medicineId = med.id,
                delta = -1,
                method = "MANUAL_TAP",
                note = "-1 ${med.unitType}"
            )
        }
    }

    fun resetActive() {
        val med = activeMedicine.value ?: return
        haptic.resetClick()
        viewModelScope.launch(Dispatchers.IO) {
            repository.setCount(
                medicineId = med.id,
                newCount = 0,
                method = "RESET",
                note = "Count reset to 0"
            )
        }
    }

    fun setTarget(target: Int) {
        val med = activeMedicine.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTarget(med.id, target)
        }
    }

    fun setStep(step: Int) {
        val med = activeMedicine.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateStep(med.id, step)
        }
    }

    fun addDetectedCountToActive(
        countToAdd: Int,
        sourceMethod: String = "LIVE_CAMERA_TRACK",
        detailNote: String = "Camera tracked $countToAdd items"
    ) {
        val med = activeMedicine.value ?: return
        if (countToAdd <= 0) return

        val expectedCount = med.currentCount.toLong() + countToAdd
        if (med.targetCount > 0 && expectedCount >= med.targetCount) {
            haptic.targetReached()
        } else {
            haptic.stepAdd()
        }

        viewModelScope.launch(Dispatchers.IO) {
            val newCount = repository.adjustCount(
                medicineId = med.id,
                delta = countToAdd,
                method = sourceMethod,
                note = detailNote
            )
            // Only confirm once the count was really stored (the medicine may have been deleted meanwhile).
            if (newCount != null) {
                _statusMessage.value = "Added +$countToAdd ${med.unitType} to ${med.name}"
            }
        }
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    // Camera Live Updates

    /** Called by the camera screen with its on-screen size so counts only include what is visible. */
    fun setViewportAspect(aspect: Float) {
        viewportAspect = if (aspect > 0f && aspect.isFinite()) aspect else 0f
    }

    fun updateLiveDetection(result: BoxDetectionEngine.DetectionResult) {
        // Detection runs on the whole camera frame, but the preview is centre-cropped to fill the
        // screen. Map boxes into what is visible and drop the ones outside, so the boxes line up with
        // the objects and the count matches what the user can actually see.
        val region = ViewportMapper.fillCenterRegion(result.frameAspect, viewportAspect)
        val visible = result.boxes.mapNotNull { ViewportMapper.toViewBox(it, region) }
        _liveDetectedBoxes.value = visible
        _liveTotalCount.value = countSmoother.add(visible.sumOf { it.estimatedUnits })
    }

    /** Forgets the last camera result (called when the camera screen is left). */
    fun clearLiveDetection() {
        countSmoother.reset()
        _liveDetectedBoxes.value = emptyList()
        _liveTotalCount.value = 0
    }

    fun toggleCameraTorch() {
        _cameraTorchEnabled.value = !_cameraTorchEnabled.value
    }

    fun setCameraTorch(enabled: Boolean) {
        _cameraTorchEnabled.value = enabled
    }

    fun setCameraSensitivity(value: Float) {
        _cameraSensitivity.value = value.coerceIn(0.1f, 0.9f)
    }

    fun setPackagingFilter(type: BoxDetectionEngine.PackagingType) {
        _packagingFilter.value = type
    }

    // Photo Inspection methods
    fun setCapturedPhoto(bitmap: Bitmap) {
        _capturedPhotoBitmap.value = bitmap
        // Never show boxes (or manual markers) of the previous photo on the new one.
        _photoDetectedBoxes.value = emptyList()
        // Automatically analyze photo
        startPhotoAnalysis(debounceMs = 0L)
    }

    /**
     * Re-runs detection on the current photo (e.g. after the sensitivity slider moved).
     * Debounced and cancellable: dragging the slider used to start dozens of overlapping analyses
     * that could finish out of order and leave boxes from an older slider position on screen.
     */
    fun reanalyzeCurrentPhoto() {
        startPhotoAnalysis(debounceMs = PHOTO_REANALYSIS_DEBOUNCE_MS)
    }

    private fun startPhotoAnalysis(debounceMs: Long) {
        val bmp = _capturedPhotoBitmap.value ?: return
        photoAnalysisJob?.cancel()
        photoAnalysisJob = viewModelScope.launch(Dispatchers.Default) {
            if (debounceMs > 0L) delay(debounceMs)
            val result = BoxDetectionEngine.analyzeBitmap(
                bitmap = bmp,
                sensitivity = _cameraSensitivity.value,
                packagingType = _packagingFilter.value
            )
            ensureActive()
            // The photo may have been replaced or cleared while the analysis was running.
            if (_capturedPhotoBitmap.value !== bmp) return@launch

            _photoDetectedBoxes.update { current ->
                // Only auto-detected boxes are recomputed; markers the user added by hand are kept.
                val manual = current.filter { it.label == MANUAL_BOX_LABEL }
                val firstFreeId = (result.boxes.maxOfOrNull { it.id } ?: 0) + 1
                result.boxes + manual.mapIndexed { index, box -> box.copy(id = firstFreeId + index) }
            }
        }
    }

    fun toggleBoxSelection(boxId: Int) {
        _photoDetectedBoxes.update { boxes ->
            boxes.map { box ->
                if (box.id == boxId) box.copy(isSelected = !box.isSelected) else box
            }
        }
    }

    fun addManualBoxAt(normX: Float, normY: Float) {
        val boxWidth = 0.12f
        val boxHeight = 0.12f
        _photoDetectedBoxes.update { current ->
            val newBox = DetectedBox(
                id = (current.maxOfOrNull { it.id } ?: 0) + 1,
                left = (normX - boxWidth / 2f).coerceIn(0f, 1f - boxWidth),
                top = (normY - boxHeight / 2f).coerceIn(0f, 1f - boxHeight),
                right = (normX + boxWidth / 2f).coerceIn(boxWidth, 1f),
                bottom = (normY + boxHeight / 2f).coerceIn(boxHeight, 1f),
                confidence = 1.0f,
                label = MANUAL_BOX_LABEL,
                estimatedUnits = 1,
                isSelected = true
            )
            current + newBox
        }
        haptic.tick()
    }

    fun clearCapturedPhoto() {
        photoAnalysisJob?.cancel()
        _capturedPhotoBitmap.value = null
        _photoDetectedBoxes.value = emptyList()
    }

    // Medicine Inventory Management
    fun saveMedicine(
        id: Long = 0,
        name: String,
        dosage: String,
        unitType: String,
        itemsPerUnit: Int,
        batchNumber: String,
        expiryDate: String,
        targetCount: Int,
        incrementStep: Int,
        colorHex: String,
        notes: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            if (id == 0L) {
                val newMed = MedicineEntity(
                    name = name.trim(),
                    dosage = dosage.trim(),
                    unitType = unitType,
                    itemsPerUnit = maxOf(1, itemsPerUnit),
                    batchNumber = batchNumber.trim(),
                    expiryDate = expiryDate.trim(),
                    currentCount = 0,
                    targetCount = maxOf(0, targetCount),
                    incrementStep = maxOf(1, incrementStep),
                    colorHex = colorHex,
                    notes = notes.trim()
                )
                val newId = repository.insertMedicine(newMed)
                _selectedMedicineId.value = newId
            } else {
                // Read-modify-write in one transaction so a tap made while the edit sheet was open
                // is not overwritten with an old count.
                repository.updateMedicineDetails(id) { existing ->
                    existing.copy(
                        name = name.trim(),
                        dosage = dosage.trim(),
                        unitType = unitType,
                        itemsPerUnit = maxOf(1, itemsPerUnit),
                        batchNumber = batchNumber.trim(),
                        expiryDate = expiryDate.trim(),
                        targetCount = maxOf(0, targetCount),
                        incrementStep = maxOf(1, incrementStep),
                        colorHex = colorHex,
                        notes = notes.trim(),
                        updatedAt = System.currentTimeMillis()
                    )
                }
            }
        }
    }

    fun deleteMedicine(medicine: MedicineEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteMedicine(medicine)
            if (_selectedMedicineId.value == medicine.id) {
                _selectedMedicineId.value = null
            }
        }
    }

    fun clearAuditLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearLogs()
        }
    }

    /**
     * Builds the exportable audit report from the database (not from the 200-entry on-screen list,
     * which silently truncated exports). Very large logs are capped so the clipboard transfer stays
     * under Android's ~1 MB IPC limit; the report header says when that happens.
     */
    suspend fun buildAuditReport(): String {
        val total = repository.logCount()
        val logs = repository.recentLogs(AUDIT_EXPORT_LIMIT)
        return AuditReportFormatter.format(logs, total)
    }

    private companion object {
        const val MANUAL_BOX_LABEL = "Manual Box"
        const val LIVE_COUNT_WINDOW = 5
        const val PHOTO_REANALYSIS_DEBOUNCE_MS = 120L
        const val AUDIT_EXPORT_LIMIT = 1500
    }
}
