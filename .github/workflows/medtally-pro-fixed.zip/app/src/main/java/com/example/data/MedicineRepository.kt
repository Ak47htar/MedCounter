package com.example.data

import androidx.room.withTransaction
import kotlinx.coroutines.flow.Flow

class MedicineRepository(private val database: AppDatabase) {
    private val medicineDao: MedicineDao = database.medicineDao()
    private val tallyLogDao: TallyLogDao = database.tallyLogDao()

    val allMedicines: Flow<List<MedicineEntity>> = medicineDao.getAllMedicines()
    val allLogs: Flow<List<TallyLogEntity>> = tallyLogDao.getAllLogs()

    suspend fun getMedicineById(id: Long): MedicineEntity? = medicineDao.getMedicineById(id)

    suspend fun insertMedicine(medicine: MedicineEntity): Long = medicineDao.insertMedicine(medicine)

    suspend fun deleteMedicine(medicine: MedicineEntity) = medicineDao.deleteMedicine(medicine)

    /**
     * Edits a medicine's details without touching a count that changed in the meantime: the row is
     * read, transformed and written inside one transaction. (Writing back a copy that was read
     * earlier could silently overwrite taps made while the edit sheet was open.)
     */
    suspend fun updateMedicineDetails(id: Long, transform: (MedicineEntity) -> MedicineEntity): Boolean =
        database.withTransaction {
            val existing = medicineDao.getMedicineById(id) ?: return@withTransaction false
            medicineDao.updateMedicine(transform(existing))
            true
        }

    /**
     * Adds [delta] (negative to remove) to the stored count and writes the audit entry, atomically.
     *
     * The new value is computed from the row *inside* the transaction, never from a UI snapshot:
     * two quick taps used to read the same stale count and the second one was lost, and the audit
     * "resulting count" could disagree with the stored count.
     *
     * @return the new count, or null when the medicine no longer exists
     */
    suspend fun adjustCount(medicineId: Long, delta: Int, method: String, note: String = ""): Int? =
        database.withTransaction {
            val current = medicineDao.getMedicineById(medicineId) ?: return@withTransaction null
            applyCount(current, clampCount(current.currentCount.toLong() + delta), method, note)
        }

    /** Sets the count to an absolute value (used by reset), atomically, with an audit entry. */
    suspend fun setCount(medicineId: Long, newCount: Int, method: String, note: String = ""): Int? =
        database.withTransaction {
            val current = medicineDao.getMedicineById(medicineId) ?: return@withTransaction null
            applyCount(current, clampCount(newCount.toLong()), method, note)
        }

    private suspend fun applyCount(current: MedicineEntity, newCount: Int, method: String, note: String): Int {
        val delta = newCount - current.currentCount
        if (delta != 0) {
            medicineDao.updateCount(current.id, newCount)
            tallyLogDao.insertLog(
                TallyLogEntity(
                    medicineId = current.id,
                    medicineName = current.name,
                    batchNumber = current.batchNumber,
                    countChange = delta,
                    resultingCount = newCount,
                    targetCount = current.targetCount,
                    method = method,
                    note = note
                )
            )
        }
        return newCount
    }

    /** Counts never go below zero or past Int.MAX_VALUE (a huge step used to overflow to negative). */
    private fun clampCount(value: Long): Int = value.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()

    suspend fun updateTarget(medicineId: Long, target: Int) {
        medicineDao.updateTarget(medicineId, maxOf(0, target))
    }

    suspend fun updateStep(medicineId: Long, step: Int) {
        medicineDao.updateStep(medicineId, maxOf(1, step))
    }

    suspend fun recentLogs(limit: Int): List<TallyLogEntity> = tallyLogDao.getRecentLogs(limit)

    suspend fun logCount(): Int = tallyLogDao.getLogCount()

    suspend fun clearLogs() {
        tallyLogDao.clearLogs()
    }
}
