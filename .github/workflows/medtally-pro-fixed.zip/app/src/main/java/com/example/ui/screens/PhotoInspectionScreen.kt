package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MedicineEntity
import com.example.util.BitmapLoader
import com.example.ui.theme.MedHudCyan
import com.example.ui.theme.MedHudGreen
import com.example.ui.theme.MedWarningAmber
import com.example.ui.viewmodel.TallyViewModel
import com.example.vision.BoxDetectionEngine
import com.example.vision.ViewportMapper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun PhotoInspectionScreen(
    viewModel: TallyViewModel,
    activeMedicine: MedicineEntity?,
    onNavigateBack: () -> Unit,
    onOpenLiveCamera: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val photoBitmap by viewModel.capturedPhotoBitmap.collectAsState()
    val detectedBoxes by viewModel.photoDetectedBoxes.collectAsState()
    val sensitivity by viewModel.cameraSensitivity.collectAsState()

    val selectedBoxesCount = detectedBoxes.filter { it.isSelected }.sumOf { it.estimatedUnits }

    // Android zero-permission Photo Picker for uploading medicine photos
    val scope = rememberCoroutineScope()
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            // The old code decoded the full-size photo on the UI thread: a 50-200 MP gallery photo ran
            // out of memory (a crash), phone photos came out rotated (EXIF ignored) and failures were
            // silent. Decode a down-sampled, correctly rotated copy in the background instead.
            scope.launch(Dispatchers.IO) {
                val bitmap = BitmapLoader.decodeFromUri(context, uri)
                withContext(Dispatchers.Main) {
                    if (bitmap != null) {
                        viewModel.setCapturedPhoto(bitmap)
                    } else {
                        Toast.makeText(context, "Couldn't open that photo.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .testTag("photo_inspection_screen")
    ) {
        if (photoBitmap != null) {
            val bmp = photoBitmap!!

            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val containerWidth = constraints.maxWidth.toFloat()
                val containerHeight = constraints.maxHeight.toFloat()

                // Where the photo is really drawn: ContentScale.Fit letter-boxes it inside the container.
                // Boxes and taps are normalised to the PHOTO, so they have to go through this rectangle. The old
                // code mapped them onto the whole container, which misplaced every box and every tap whenever the
                // photo's aspect ratio differed from the screen area (always, for landscape photos).
                val fit = remember(bmp, containerWidth, containerHeight) {
                    ViewportMapper.fitRect(
                        bmp.width.toFloat(),
                        bmp.height.toFloat(),
                        containerWidth,
                        containerHeight
                    )
                }

                // Display photo with fit content scale
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = "Captured medicine photo",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit
                )

                // Interactive touch layer for tapping boxes or adding manual markers
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(detectedBoxes, fit) {
                            detectTapGestures { tapOffset ->
                                // Taps outside the photo (letter-box bars) are ignored
                                val point = fit?.let { ViewportMapper.toImageNormalized(tapOffset.x, tapOffset.y, it) }
                                    ?: return@detectTapGestures
                                val (normX, normY) = point

                                // Check if tapped inside an existing detected box
                                val tappedBox = detectedBoxes.find { it.containsNormalized(normX, normY) }
                                if (tappedBox != null) {
                                    viewModel.toggleBoxSelection(tappedBox.id)
                                    viewModel.haptic.tick()
                                } else {
                                    // Add manual box at this coordinate
                                    viewModel.addManualBoxAt(normX, normY)
                                }
                            }
                        }
                        .testTag("photo_boxes_canvas")
                ) {
                    val rect = fit ?: ViewportMapper.FitRect(0f, 0f, size.width, size.height)

                    for (box in detectedBoxes) {
                        val left = rect.left + box.left * rect.width
                        val top = rect.top + box.top * rect.height
                        val right = rect.left + box.right * rect.width
                        val bottom = rect.top + box.bottom * rect.height
                        val w = right - left
                        val h = bottom - top

                        val boxColor = if (box.isSelected) MedHudGreen else Color.Gray.copy(alpha = 0.5f)

                        // Box fill
                        drawRect(
                            color = boxColor.copy(alpha = if (box.isSelected) 0.15f else 0.05f),
                            topLeft = Offset(left, top),
                            size = Size(w, h)
                        )

                        // Border
                        drawRect(
                            color = boxColor,
                            topLeft = Offset(left, top),
                            size = Size(w, h),
                            style = Stroke(width = if (box.isSelected) 3.dp.toPx() else 1.5.dp.toPx())
                        )

                        // Corner accent marks
                        val cornerLen = minOf(w, h) * 0.2f
                        drawLine(boxColor, Offset(left, top), Offset(left + cornerLen, top), 5f)
                        drawLine(boxColor, Offset(left, top), Offset(left, top + cornerLen), 5f)
                        drawLine(boxColor, Offset(right, top), Offset(right - cornerLen, top), 5f)
                        drawLine(boxColor, Offset(right, top), Offset(right, top + cornerLen), 5f)
                        drawLine(boxColor, Offset(left, bottom), Offset(left + cornerLen, bottom), 5f)
                        drawLine(boxColor, Offset(left, bottom), Offset(left, bottom - cornerLen), 5f)
                        drawLine(boxColor, Offset(right, bottom), Offset(right - cornerLen, bottom), 5f)
                        drawLine(boxColor, Offset(right, bottom), Offset(right, bottom - cornerLen), 5f)

                        // Selection indicator circle
                        drawCircle(
                            color = boxColor,
                            radius = 6.dp.toPx(),
                            center = Offset(left + w / 2f, top + h / 2f)
                        )
                    }
                }
            }
        } else {
            // Empty State: Prompt user to take or choose photo
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(80.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.PhotoCamera,
                            contentDescription = "Camera",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Medicine Photo Counting",
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Spread medicine boxes or blister packs on a counter and capture a photo. The system will detect and highlight each package.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.8f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                Spacer(modifier = Modifier.height(28.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = onOpenLiveCamera,
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Open Camera")
                    }

                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Upload Photo")
                    }
                }
            }
        }

        // Top Navigation Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier.size(44.dp)
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MedHudGreen.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Photo Count: $selectedBoxesCount ${activeMedicine?.unitType ?: "Boxes"}",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MedHudGreen
                        )
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier.size(44.dp)
                ) {
                    IconButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Choose new photo",
                            tint = Color.White
                        )
                    }
                }
            }

            if (photoBitmap != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.Black.copy(alpha = 0.7f),
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                ) {
                    Text(
                        text = "Tap any box to toggle • Tap empty space to add box marker",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.9f),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Bottom Action Bar when photo is loaded
        if (photoBitmap != null) {
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .navigationBarsPadding(),
                color = Color.Black.copy(alpha = 0.9f),
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    // Sensitivity Slider for instant re-thresholding
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Detection Sensitivity: ${(sensitivity * 100).toInt()}%",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White.copy(alpha = 0.7f)
                        )
                        IconButton(
                            onClick = { viewModel.reanalyzeCurrentPhoto() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Re-analyze",
                                tint = MedHudCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Slider(
                        value = sensitivity,
                        onValueChange = {
                            viewModel.setCameraSensitivity(it)
                            viewModel.reanalyzeCurrentPhoto()
                        },
                        valueRange = 0.1f..0.9f
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.clearCapturedPhoto() },
                            modifier = Modifier.weight(1f).height(50.dp),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Clear Photo", color = Color.White)
                        }

                        Button(
                            onClick = {
                                if (selectedBoxesCount > 0) {
                                    viewModel.addDetectedCountToActive(
                                        countToAdd = selectedBoxesCount,
                                        sourceMethod = "PHOTO_SCAN",
                                        detailNote = "Verified photo scan of $selectedBoxesCount items"
                                    )
                                    // The scan has been applied: drop it, otherwise coming back to this screen shows the same
                                    // photo and a second tap on APPLY would count the same items twice.
                                    viewModel.clearCapturedPhoto()
                                    onNavigateBack()
                                }
                            },
                            enabled = selectedBoxesCount > 0 && activeMedicine != null,
                            modifier = Modifier.weight(2f).height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MedHudGreen,
                                contentColor = Color(0xFF042F2E)
                            )
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "APPLY +$selectedBoxesCount TO TALLY",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
