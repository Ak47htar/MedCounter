package com.example.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [MedicineEntity::class, TallyLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun medicineDao(): MedicineDao
    abstract fun tallyLogDao(): TallyLogDao

    companion object {
        private const val DATABASE_NAME = "medtally_pro_database"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                // Re-check inside the lock: two threads may have both seen null above.
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .addCallback(SeedCallback)
                    .build()
                    .also { INSTANCE = it }
            }
        }

        /**
         * Seeds the demo data exactly once, synchronously, inside the transaction that creates the
         * database file. (The old code seeded from a coroutine in onCreate AND again from the
         * ViewModel whenever the table was empty, which duplicated the demo medicines on first
         * launch and brought them back after the user deleted them all.)
         */
        private object SeedCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                seedInitialData(db)
            }
        }

        internal fun seedInitialData(db: SupportSQLiteDatabase, now: Long = System.currentTimeMillis()) {
            // Distinct updatedAt values: the first one is the "most recent", so it is the medicine
            // selected by default on first launch.
            val medicines = listOf(
                MedicineEntity(
                    name = "Amoxicillin 500mg",
                    dosage = "500 mg Capsules",
                    unitType = "Boxes",
                    itemsPerUnit = 20,
                    batchNumber = "AMX-2026-904",
                    expiryDate = "11/2027",
                    currentCount = 8,
                    targetCount = 25,
                    incrementStep = 1,
                    colorHex = "#0F766E",
                    notes = "Oral antibiotic. Count by retail box.",
                    updatedAt = now
                ),
                MedicineEntity(
                    name = "Paracetamol 650mg",
                    dosage = "650 mg Tablets",
                    unitType = "Boxes",
                    itemsPerUnit = 10,
                    batchNumber = "PCM-2026-118",
                    expiryDate = "08/2028",
                    currentCount = 14,
                    targetCount = 30,
                    incrementStep = 5,
                    colorHex = "#0284C7",
                    notes = "Antipyretic / Analgesic. High turnover stock.",
                    updatedAt = now - 1
                ),
                MedicineEntity(
                    name = "Omeprazole 20mg",
                    dosage = "20 mg Delayed-Release",
                    unitType = "Blister Packs",
                    itemsPerUnit = 14,
                    batchNumber = "OMP-2026-442",
                    expiryDate = "05/2027",
                    currentCount = 12,
                    targetCount = 12,
                    incrementStep = 1,
                    colorHex = "#7C3AED",
                    notes = "Proton pump inhibitor blister strips.",
                    updatedAt = now - 2
                ),
                MedicineEntity(
                    name = "Dextromethorphan Syrup",
                    dosage = "100 ml Oral Solution",
                    unitType = "Bottles",
                    itemsPerUnit = 1,
                    batchNumber = "DXM-2026-302",
                    expiryDate = "03/2027",
                    currentCount = 5,
                    targetCount = 10,
                    incrementStep = 1,
                    colorHex = "#D97706",
                    notes = "Cough suppressant syrup cartons/bottles.",
                    updatedAt = now - 3
                )
            )

            val ids = medicines.map { medicine ->
                db.insert("medicines", SQLiteDatabase.CONFLICT_NONE, medicine.toContentValues())
            }

            val logs = listOf(
                TallyLogEntity(
                    medicineId = ids[0],
                    medicineName = medicines[0].name,
                    batchNumber = medicines[0].batchNumber,
                    countChange = 8,
                    resultingCount = 8,
                    targetCount = 25,
                    method = "MANUAL_TAP",
                    note = "Initial stock intake",
                    timestamp = now - 86_400_000L
                ),
                TallyLogEntity(
                    medicineId = ids[1],
                    medicineName = medicines[1].name,
                    batchNumber = medicines[1].batchNumber,
                    countChange = 14,
                    resultingCount = 14,
                    targetCount = 30,
                    method = "LIVE_CAMERA_TRACK",
                    note = "Camera verified shelf batch",
                    timestamp = now - 3_600_000L
                )
            )
            logs.forEach { log ->
                db.insert("tally_logs", SQLiteDatabase.CONFLICT_NONE, log.toContentValues())
            }
        }

        // Column names are the property names of the entities (Room's default). The id column is
        // left out so SQLite assigns it (autoGenerate = true).
        private fun MedicineEntity.toContentValues(): ContentValues {
            val values = ContentValues()
            values.put("name", name)
            values.put("dosage", dosage)
            values.put("unitType", unitType)
            values.put("itemsPerUnit", itemsPerUnit)
            values.put("batchNumber", batchNumber)
            values.put("expiryDate", expiryDate)
            values.put("currentCount", currentCount)
            values.put("targetCount", targetCount)
            values.put("incrementStep", incrementStep)
            values.put("colorHex", colorHex)
            values.put("notes", notes)
            values.put("updatedAt", updatedAt)
            return values
        }

        private fun TallyLogEntity.toContentValues(): ContentValues {
            val values = ContentValues()
            values.put("medicineId", medicineId)
            values.put("medicineName", medicineName)
            values.put("batchNumber", batchNumber)
            values.put("countChange", countChange)
            values.put("resultingCount", resultingCount)
            values.put("targetCount", targetCount)
            values.put("method", method)
            values.put("note", note)
            values.put("timestamp", timestamp)
            return values
        }
    }
}
