package com.example.vision

import android.graphics.Bitmap
import androidx.camera.core.ImageProxy
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object BoxDetectionEngine {

    enum class PackagingType {
        BOXES,
        BLISTER_PACKS,
        BOTTLES
    }

    data class DetectionResult(
        val boxes: List<DetectedBox>,
        val totalCount: Int,
        val processingTimeMs: Long,
        val confidence: Float,
        /** Upright (rotation-corrected) size of the analysed frame in pixels; 0 when unknown. */
        val frameWidth: Int = 0,
        val frameHeight: Int = 0
    ) {
        /** Width / height of the upright frame, or 0 when unknown. */
        val frameAspect: Float
            get() = if (frameWidth > 0 && frameHeight > 0) frameWidth.toFloat() / frameHeight else 0f
    }

    /**
     * Detects medicine boxes/packages from a CameraX ImageProxy (YUV_420_888).
     * Extracts Y-plane directly for maximum speed and zero memory allocation.
     */
    fun analyzeCameraFrame(
        imageProxy: ImageProxy,
        sensitivity: Float = 0.5f,
        packagingType: PackagingType = PackagingType.BOXES
    ): DetectionResult {
        val startTime = System.currentTimeMillis()
        try {
            val yPlane = imageProxy.planes[0]
            val buffer: ByteBuffer = yPlane.buffer
            val width = imageProxy.width
            val height = imageProxy.height
            val rowStride = yPlane.rowStride
            val pixelStride = yPlane.pixelStride

            // Downsample target dimensions for real-time 30fps analysis
            val sampleScale = max(1, min(width, height) / 160)
            val sampleW = width / sampleScale
            val sampleH = height / sampleScale

            val gray = IntArray(sampleW * sampleH)
            val hist = IntArray(256)

            for (y in 0 until sampleH) {
                val origY = y * sampleScale
                val rowOffset = origY * rowStride
                for (x in 0 until sampleW) {
                    val origX = x * sampleScale
                    val byteIndex = rowOffset + (origX * pixelStride)
                    val pixel = if (byteIndex < buffer.limit()) {
                        buffer.get(byteIndex).toInt() and 0xFF
                    } else 128
                    gray[y * sampleW + x] = pixel
                    hist[pixel]++
                }
            }

            val boxes = detectObjectsFromGrayscale(
                gray = gray,
                hist = hist,
                w = sampleW,
                h = sampleH,
                sensitivity = sensitivity,
                packagingType = packagingType
            )

            val rotationDegrees = imageProxy.imageInfo.rotationDegrees
            val orientedBoxes = orientBoxes(boxes, rotationDegrees)
            val swapped = rotationDegrees == 90 || rotationDegrees == 270
            val uprightW = if (swapped) height else width
            val uprightH = if (swapped) width else height

            val totalCount = orientedBoxes.sumOf { it.estimatedUnits }
            val duration = System.currentTimeMillis() - startTime
            val avgConfidence = if (orientedBoxes.isNotEmpty()) {
                orientedBoxes.map { it.confidence }.average().toFloat()
            } else 0.8f

            return DetectionResult(
                boxes = orientedBoxes,
                totalCount = totalCount,
                processingTimeMs = duration,
                confidence = avgConfidence,
                frameWidth = uprightW,
                frameHeight = uprightH
            )
        } catch (e: Exception) {
            return DetectionResult(emptyList(), 0, 0, 0f)
        }
    }

    /**
     * Detects medicine boxes/packages from a Bitmap (Photo or Freeze frame).
     */
    fun analyzeBitmap(
        bitmap: Bitmap,
        sensitivity: Float = 0.5f,
        packagingType: PackagingType = PackagingType.BOXES
    ): DetectionResult {
        val startTime = System.currentTimeMillis()
        val origW = bitmap.width
        val origH = bitmap.height

        val maxDim = 400
        val scale = min(1f, maxDim.toFloat() / max(origW, origH))

        val scaledBitmap = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bitmap,
                max(32, (origW * scale).roundToInt()),
                max(32, (origH * scale).roundToInt()),
                true
            )
        } else {
            bitmap
        }

        // Always use the size of the bitmap we actually read from. (Forcing a 32px minimum even for
        // an unscaled bitmap made getPixels() throw for very small images.)
        val sampleW = scaledBitmap.width
        val sampleH = scaledBitmap.height

        val pixels = IntArray(sampleW * sampleH)
        scaledBitmap.getPixels(pixels, 0, sampleW, 0, 0, sampleW, sampleH)
        if (scaledBitmap !== bitmap) scaledBitmap.recycle()

        val gray = IntArray(sampleW * sampleH)
        val hist = IntArray(256)

        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val y = (r * 77 + g * 150 + b * 29) shr 8
            gray[i] = y
            hist[y]++
        }

        val boxes = detectObjectsFromGrayscale(
            gray = gray,
            hist = hist,
            w = sampleW,
            h = sampleH,
            sensitivity = sensitivity,
            packagingType = packagingType
        )

        val totalCount = boxes.sumOf { it.estimatedUnits }
        val duration = System.currentTimeMillis() - startTime
        val avgConfidence = if (boxes.isNotEmpty()) {
            boxes.map { it.confidence }.average().toFloat()
        } else 0.9f

        return DetectionResult(
            boxes = boxes,
            totalCount = totalCount,
            processingTimeMs = duration,
            confidence = avgConfidence
        )
    }

    private fun detectObjectsFromGrayscale(
        gray: IntArray,
        hist: IntArray,
        w: Int,
        h: Int,
        sensitivity: Float,
        packagingType: PackagingType
    ): List<DetectedBox> {
        val n = w * h
        if (n == 0) return emptyList()

        // Otsu's thresholding for contrast separation
        var sum = 0L
        for (i in 0 until 256) sum += i.toLong() * hist[i]

        var wB = 0L
        var sB = 0L
        var maxVariance = 0.0
        var otsuThreshold = 128

        for (t in 0 until 256) {
            wB += hist[t]
            if (wB == 0L) continue
            val wF = n - wB
            if (wF == 0L) break
            sB += t.toLong() * hist[t]

            val mB = sB.toDouble() / wB
            val mF = (sum - sB).toDouble() / wF
            val variance = wB.toDouble() * wF.toDouble() * (mB - mF) * (mB - mF)

            if (variance > maxVariance) {
                maxVariance = variance
                otsuThreshold = t
            }
        }

        // Adjust threshold by sensitivity offset
        val sensitivityShift = ((sensitivity - 0.5f) * 50).toInt()
        val threshold = (otsuThreshold + sensitivityShift).coerceIn(20, 235)

        // Sample border pixels to detect dominant background luminance
        val borderMargin = max(2, min(w, h) / 12)
        var borderSum = 0L
        var borderCount = 0

        for (y in 0 until h) {
            for (x in 0 until w) {
                if (x < borderMargin || y < borderMargin || x >= w - borderMargin || y >= h - borderMargin) {
                    borderSum += gray[y * w + x]
                    borderCount++
                }
            }
        }

        val borderMean = if (borderCount > 0) borderSum / borderCount else 128L
        val bgIsDark = borderMean <= threshold

        // Generate binary foreground mask
        val binary = BooleanArray(n)
        for (i in 0 until n) {
            val isFore = if (bgIsDark) gray[i] > threshold else gray[i] <= threshold
            binary[i] = isFore
        }

        // Connected-Component Labeling (Two-pass BFS)
        val visited = BooleanArray(n)
        val rawComponents = mutableListOf<RawComponent>()

        val minArea = max(16, (n * 0.003f).toInt()) // At least 0.3% of screen
        val maxArea = (n * 0.70f).toInt() // At most 70% of screen

        // One packed queue of pixel indices (y * w + x), reused for every component.
        val queue = IntArray(n)

        for (startY in 0 until h) {
            for (startX in 0 until w) {
                val startIdx = startY * w + startX
                if (!binary[startIdx] || visited[startIdx]) continue

                var head = 0
                var tail = 0
                queue[tail++] = startIdx
                visited[startIdx] = true

                var minX = startX
                var maxX = startX
                var minY = startY
                var maxY = startY
                var area = 0

                while (head < tail) {
                    val idx = queue[head++]
                    val cy = idx / w
                    val cx = idx - cy * w
                    area++

                    if (cx < minX) minX = cx
                    if (cx > maxX) maxX = cx
                    if (cy < minY) minY = cy
                    if (cy > maxY) maxY = cy

                    // 4-neighborhood (left, right, up, down) - checked inline so the hot loop
                    // allocates nothing; this runs for every foreground pixel of every camera frame.
                    if (cx > 0) {
                        val nIdx = idx - 1
                        if (binary[nIdx] && !visited[nIdx]) { visited[nIdx] = true; queue[tail++] = nIdx }
                    }
                    if (cx < w - 1) {
                        val nIdx = idx + 1
                        if (binary[nIdx] && !visited[nIdx]) { visited[nIdx] = true; queue[tail++] = nIdx }
                    }
                    if (cy > 0) {
                        val nIdx = idx - w
                        if (binary[nIdx] && !visited[nIdx]) { visited[nIdx] = true; queue[tail++] = nIdx }
                    }
                    if (cy < h - 1) {
                        val nIdx = idx + w
                        if (binary[nIdx] && !visited[nIdx]) { visited[nIdx] = true; queue[tail++] = nIdx }
                    }
                }

                if (area in minArea..maxArea) {
                    val boxW = (maxX - minX + 1)
                    val boxH = (maxY - minY + 1)
                    val aspect = boxW.toFloat() / boxH.toFloat()
                    val boundingArea = boxW * boxH
                    val fillRatio = area.toFloat() / boundingArea

                    // Medicine box packaging geometric validation
                    val aspectOk = when (packagingType) {
                        PackagingType.BOXES -> aspect in 0.25f..4.0f
                        PackagingType.BLISTER_PACKS -> aspect in 0.35f..3.5f
                        PackagingType.BOTTLES -> aspect in 0.2f..2.5f
                    }

                    if (aspectOk && fillRatio > 0.22f) {
                        rawComponents.add(
                            RawComponent(
                                minX = minX,
                                minY = minY,
                                maxX = maxX,
                                maxY = maxY,
                                area = area,
                                fillRatio = fillRatio
                            )
                        )
                    }
                }
            }
        }

        if (rawComponents.isEmpty()) return emptyList()

        // Non-Maximum Suppression / Overlap Merging
        val filtered = suppressOverlaps(rawComponents)

        // Calculate median area to estimate packed/touching medicine cartons
        val sortedAreas = filtered.map { it.area }.sorted()
        val medianArea = sortedAreas[sortedAreas.size / 2]

        val detectedBoxes = mutableListOf<DetectedBox>()
        var idCounter = 1

        val labelName = when (packagingType) {
            PackagingType.BOXES -> "Box"
            PackagingType.BLISTER_PACKS -> "Blister"
            PackagingType.BOTTLES -> "Bottle"
        }

        for (comp in filtered) {
            val normLeft = comp.minX.toFloat() / w
            val normTop = comp.minY.toFloat() / h
            val normRight = (comp.maxX + 1).toFloat() / w
            val normBottom = (comp.maxY + 1).toFloat() / h

            // Estimate multi-units for touching boxes on counter
            val unitEstimate = if (comp.area > medianArea * 1.7f) {
                min(6, max(1, (comp.area.toFloat() / medianArea).roundToInt()))
            } else 1

            val conf = (0.75f + min(0.20f, comp.fillRatio * 0.3f)).coerceIn(0.6f, 0.98f)

            detectedBoxes.add(
                DetectedBox(
                    id = idCounter++,
                    left = normLeft.coerceIn(0f, 1f),
                    top = normTop.coerceIn(0f, 1f),
                    right = normRight.coerceIn(0f, 1f),
                    bottom = normBottom.coerceIn(0f, 1f),
                    confidence = conf,
                    label = "$labelName #${idCounter - 1}",
                    estimatedUnits = unitEstimate,
                    isSelected = true
                )
            )
        }

        return detectedBoxes
    }

    private data class RawComponent(
        val minX: Int,
        val minY: Int,
        val maxX: Int,
        val maxY: Int,
        val area: Int,
        val fillRatio: Float
    )

    private fun suppressOverlaps(list: List<RawComponent>): List<RawComponent> {
        val sorted = list.sortedByDescending { it.area }.toMutableList()
        val result = mutableListOf<RawComponent>()

        while (sorted.isNotEmpty()) {
            val best = sorted.removeAt(0)
            result.add(best)

            sorted.removeAll { other ->
                val overlapX = max(0, min(best.maxX, other.maxX) - max(best.minX, other.minX))
                val overlapY = max(0, min(best.maxY, other.maxY) - max(best.minY, other.minY))
                val overlapArea = overlapX * overlapY
                val otherArea = (other.maxX - other.minX + 1) * (other.maxY - other.minY + 1)
                (overlapArea.toFloat() / otherArea.toFloat()) > 0.45f
            }
        }
        return result
    }

    private fun orientBoxes(boxes: List<DetectedBox>, rotationDegrees: Int): List<DetectedBox> {
        if (rotationDegrees == 0) return boxes
        return boxes.map { b ->
            when (rotationDegrees) {
                90 -> DetectedBox(
                    id = b.id,
                    left = 1f - b.bottom,
                    top = b.left,
                    right = 1f - b.top,
                    bottom = b.right,
                    confidence = b.confidence,
                    label = b.label,
                    estimatedUnits = b.estimatedUnits,
                    isSelected = b.isSelected
                )
                180 -> DetectedBox(
                    id = b.id,
                    left = 1f - b.right,
                    top = 1f - b.bottom,
                    right = 1f - b.left,
                    bottom = 1f - b.top,
                    confidence = b.confidence,
                    label = b.label,
                    estimatedUnits = b.estimatedUnits,
                    isSelected = b.isSelected
                )
                270 -> DetectedBox(
                    id = b.id,
                    left = b.top,
                    top = 1f - b.right,
                    right = b.bottom,
                    bottom = 1f - b.left,
                    confidence = b.confidence,
                    label = b.label,
                    estimatedUnits = b.estimatedUnits,
                    isSelected = b.isSelected
                )
                else -> b
            }
        }
    }
}
